"""
Paolo Filice — PDF Misure + Grafici  [CARBON — versione corretta]

Fix applicati:
  1. Tabella storico misurazioni → pagina landscape dedicata (25 col, tutto visibile)
  2. Forma corporea → calcolata correttamente per fascia età (uomo 40-49)
  3. Grafico composizione → barre impilate verticali (kg adipe + kg magra) stile InBody
  4. Plicometrie + Circonferenze → stessa pagina portrait, ridimensionate, mai tagliate
  5. Linea peso → bianca
  6. Tabella riferimento → contrasto fix (testo scuro su sfondo colorato)
"""

import openpyxl, datetime
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
    TableStyle, HRFlowable, PageBreak, Flowable, KeepTogether)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

# ── PALETTE CARBON ────────────────────────────────────────────────────────────
C = {
    'bg':        '#0F172A',
    'panel':     '#1E293B',
    'panel2':    '#253047',
    'green':     '#22C55E',
    'blue':      '#3B82F6',
    'amber':     '#F59E0B',
    'rose':      '#F43F5E',
    'violet':    '#A78BFA',
    'white':     '#F1F5F9',
    'sub':       '#94A3B8',
    'dim':       '#64748B',
    'border':    '#334155',
    'grid':      '#1E3050',
}
def hc(k):  return colors.HexColor(C[k])
def hex(s): return colors.HexColor(s)

# ── LOAD DATA ─────────────────────────────────────────────────────────────────
def load_data(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ms = wb['Misure']
    fm = wb['Formule misure']

    d = {}
    d['nome']    = ms['I1'].value or ''
    d['altezza'] = ms['I2'].value or 0
    d['nascita'] = ms['I3'].value
    d['eta']     = ms['I4'].value or 0

    # ── Legge genere, formula e soglie FM% dal foglio R_M ──
    d['genere'] = 'UOMO'  # default
    d['soglie_fm'] = {}
    fm_col = 16  # default col Q = m3 uomo
    if 'R_M' in wb.sheetnames:
        rm = wb['R_M']
        genere_val = rm['B13'].value
        formula_val = rm['B12'].value or ''
        genere_str = str(genere_val).strip().upper() if genere_val else ''
        if genere_str == 'DONNA':
            d['genere'] = 'DONNA'
        else:
            d['genere'] = 'UOMO'  # default esplicito: UOMO se non è esattamente DONNA
        # Mappa formula -> colonna index in Formule misure
        FORMULA_COL = {
            'jp 3':         {'UOMO': 8,  'DONNA': 12},
            'jp7':          {'UOMO': 10, 'DONNA': 14},
            'm3':           {'UOMO': 16, 'DONNA': 19},
            'm7 molto all': {'UOMO': 17, 'DONNA': 20},
            'm_media':      {'UOMO': 18, 'DONNA': 21},
            'f3':           {'UOMO': 16, 'DONNA': 19},
            'f7 molto all': {'UOMO': 17, 'DONNA': 20},
            'f_media':      {'UOMO': 18, 'DONNA': 21},
        }
        fm_col = FORMULA_COL.get(formula_val, {}).get(d['genere'], 16)

        eta_val = d['eta'] or 30
        col_offset = 2 if d['genere'] == 'DONNA' else 1
        best_row = None
        for r in rm.iter_rows(min_row=2, max_row=11, values_only=True):
            if r[0] and isinstance(r[0], (int, float)):
                if r[0] <= eta_val:
                    best_row = r
        if best_row:
            d['soglie_fm'] = {
                'essenziale': best_row[col_offset] * 100,
                'atleta':     best_row[col_offset + 2] * 100,
                'buona':      best_row[col_offset + 4] * 100,
                'accettabile':best_row[col_offset + 6] * 100,
                'sovrappeso': best_row[col_offset + 8] * 100,
            }

    def get_forma(fm_pct, soglie):
        if fm_pct is None: return '–'
        if not soglie:
            # fallback uomo generico
            if fm_pct < 5:   return 'Grasso essenziale'
            if fm_pct < 14:  return 'Atleta'
            if fm_pct < 16:  return 'Forma buona'
            if fm_pct < 22:  return 'Accettabile'
            if fm_pct < 28:  return 'Sovrappeso'
            return 'Obesità'
        if fm_pct < soglie['essenziale']: return 'Grasso essenziale'
        if fm_pct < soglie['atleta']:     return 'Atleta'
        if fm_pct < soglie['buona']:      return 'Forma buona'
        if fm_pct < soglie['accettabile']:return 'Accettabile'
        if fm_pct < soglie['sovrappeso']: return 'Sovrappeso'
        return 'Obesità'

    rows_ms = [r for r in ms.iter_rows(min_row=7, max_row=ms.max_row, values_only=True)
               if r[0] and isinstance(r[0], datetime.datetime)]
    rows_fm = [r for r in fm.iter_rows(min_row=3, max_row=fm.max_row, values_only=True)
               if r[0] and isinstance(r[0], datetime.datetime)]

    # FM% — usa colonna determinata da formula+genere in R_M, delta vs PRIMA sessione
    fm_vals = []
    for rfm in rows_fm:
        raw = rfm[fm_col]
        # Se il valore è già > 1 è già percentuale, altrimenti moltiplica per 100
        pct = round(raw * 100, 1) if (raw and raw < 1) else (round(raw, 1) if raw else None)
        fm_vals.append(pct)
    first_fm = fm_vals[0]
    fm_list = []
    for i, pct in enumerate(fm_vals):
        dtot = round(pct - first_fm, 1) if (pct is not None and first_fm is not None) else None
        fm_list.append((pct, dtot))

    # Massa magra — delta sempre vs PRIMA sessione
    first_mg = round(rows_fm[0][6], 1) if rows_fm[0][6] else None
    mg_list = []
    for rfm in rows_fm:
        mg = round(rfm[6], 1) if rfm[6] else None
        dtot_mg = round(mg - first_mg, 1) if (mg is not None and first_mg is not None) else None
        mg_list.append((mg, dtot_mg))

    def safe(v, dec=1):
        if v is None or isinstance(v, str): return None
        try: return round(float(v), dec)
        except: return None

    # Helper: delta tupla (val, Δ_vs_prima)
    def dt(val, first_val):
        if val is None or first_val is None: return None
        return round(val - first_val, 1)

    d['sessions'] = []
    r0 = rows_ms[0]
    rfm0 = rows_fm[0]
    first_adipe = round(rfm0[5], 1) if rfm0[5] else None
    first_peso0 = safe(rows_ms[0][1])

    for i, (r, rfm) in enumerate(zip(rows_ms, rows_fm)):
        fm_pct, fm_dtot = fm_list[i]
        kg_magra, dtot_mg = mg_list[i]
        kg_adipe = round(rfm[5], 2) if rfm[5] else None
        dtot_adipe = round(kg_adipe - first_adipe, 2) if (kg_adipe and first_adipe) else None
        bmi = round(rfm[23], 1) if rfm[23] else None
        forma = get_forma(fm_pct, d['soglie_fm'])

        # FM% e Massa Magra % calcolati da kg
        peso_val = safe(r[1])
        kg_adipe_pct  = round(kg_adipe / peso_val * 100, 1) if (kg_adipe and peso_val) else None
        kg_magra_pct  = round(kg_magra / peso_val * 100, 1) if (kg_magra and peso_val) else None

        # Δ tot FM% e magra% vs prima sessione
        first_adipe_pct = round(first_adipe / first_peso0 * 100, 1) if (first_adipe and first_peso0) else None
        first_magra_pct = round(mg_list[0][0] / first_peso0 * 100, 1) if (mg_list[0][0] and first_peso0) else None
        dtot_adipe_pct = round(kg_adipe_pct - first_adipe_pct, 1) if (kg_adipe_pct and first_adipe_pct) else None
        dtot_magra_pct = round(kg_magra_pct - first_magra_pct, 1) if (kg_magra_pct and first_magra_pct) else None

        def mk(col_v, col_first):
            v = safe(r[col_v])
            f = safe(r0[col_first])
            return (v, dt(v, f))

        s = {
            'data':         r[0],
            'peso':         safe(r[1]),
            'dtot_peso':    dt(safe(r[1]), safe(r0[1])),
            'fm_pct':       fm_pct,
            'dtot_fm':      fm_dtot,
            'kg_adipe':     kg_adipe,
            'dtot_adipe':   dtot_adipe,
            'kg_adipe_pct': kg_adipe_pct,
            'dtot_adipe_pct': dtot_adipe_pct,
            'kg_magra':     kg_magra,
            'dtot_mg':      dtot_mg,
            'kg_magra_pct': kg_magra_pct,
            'dtot_magra_pct': dtot_magra_pct,
            'bmi':          bmi,
            'forma':        forma,
            # Plicometrie (val, Δ_vs_prima)
            'petto':       mk(5,  5),
            'tricipite':   mk(8,  8),
            'ascella':     mk(11, 11),
            'scapola':     mk(14, 14),
            'soprailiaca': mk(17, 17),
            'addominale':  mk(20, 20),
            'coscia_p':    mk(23, 23),
            # Circonferenze (val, Δ_vs_prima)
            'collo':      mk(27, 27),
            'torace':     mk(30, 30),
            'br_ril':     mk(33, 33),
            'br_con':     mk(36, 36),
            'vita':       mk(39, 39),
            'add_basso':  mk(42, 42),
            'fianchi':    mk(45, 45),
            'cos_alta':   mk(48, 48),
            'cos_media':  mk(51, 51),
            'cos_bassa':  mk(54, 54),
            'polpaccio':  mk(57, 57),
        }
        d['sessions'].append(s)

    d['ultima'] = d['sessions'][-1]
    return d

# ── HELPERS ───────────────────────────────────────────────────────────────────
def fv(v, dec=1):
    if v is None: return '–'
    return f'{v:.{dec}f}'

def fd(v, dec=1):
    if v is None: return '–'
    if abs(v) < 0.005: return '='
    return f'{v:+.{dec}f}'

def dpara(v, sty, invert=False):
    """Colored delta paragraph"""
    s = fd(v)
    if s == '–': return Paragraph('–', sty)
    if s == '=': return Paragraph('<font color="#64748B">=</font>', sty)
    col = ('#22C55E' if (v < 0) != invert else '#F43F5E')
    return Paragraph(f'<font color="{col}">{s}</font>', sty)

# ── PARA STYLE FACTORY ────────────────────────────────────────────────────────
def S(name, fn='Helvetica', fs=8, tc='#F1F5F9', al=TA_LEFT, ld=None, sa=1, sb=0, li=0):
    return ParagraphStyle(name, fontName=fn, fontSize=fs,
        textColor=hex(tc), alignment=al,
        leading=ld or fs+3.5, spaceAfter=sa, spaceBefore=sb, leftIndent=li)

# ── CHART: LINE (per peso e circonferenze) ────────────────────────────────────
class LineChart(Flowable):
    def __init__(self, series, width, height, title, line_colors=None, show_points=True):
        super().__init__()
        self.series = series          # [(label, [(date,val),...]), ...]
        self.width  = width
        self.height = height
        self.title  = title
        self.lcolors = line_colors or ['#FFFFFF']
        self.show_points = show_points

    def draw(self):
        c = self.canv
        w, h = self.width, self.height
        # Padding: PL grande abbastanza per etichette Y, PR a destra per ultimo punto
        PL = max(36, min(44, int(w * 0.12)))
        PR = max(20, int(w * 0.06))   # margine destra per ultimo punto
        PT = 44   # spazio per titolo (riga 1) + legenda (riga 2)
        PB = 28

        c.setFillColor(hex(C['bg']))
        c.roundRect(0, 0, w, h, 8, fill=1, stroke=0)

        cx = PL; cw = w - PL - PR
        cy = PB; ch = h - PT - PB

        # Titolo — riga 1 in alto
        c.setFillColor(hex(C['white'])); c.setFont('Helvetica-Bold', 8.5)
        c.drawString(cx, h - 18, self.title)

        # Legenda — riga 2, sotto il titolo
        leg_y = h - 34
        leg_x = cx
        for si, (lbl, _) in enumerate(self.series):
            lcol = self.lcolors[si % len(self.lcolors)]
            c.setFillColor(hex(lcol)); c.roundRect(leg_x, leg_y, 9, 6, 2, fill=1, stroke=0)
            c.setFillColor(hex(C['sub'])); c.setFont('Helvetica', 6.5)
            c.drawString(leg_x + 12, leg_y + 0.5, lbl)
            leg_x += 12 + c.stringWidth(lbl, 'Helvetica', 6.5) + 12

        # Collect values
        all_vals = [v for _, pts in self.series for _, v in pts if v is not None]
        if not all_vals: return
        vmin = min(all_vals); vmax = max(all_vals)
        rng = vmax - vmin or 1
        vmin -= rng * 0.12; vmax += rng * 0.18

        n = max(len(pts) for _, pts in self.series)
        # Offset laterale: il primo punto parte a PR/2 dall'inizio area, l'ultimo a PR/2 dalla fine
        # così le etichette non escono mai
        margin = PR * 0.6
        def px(i): return cx + margin + i * (cw - 2*margin) / max(n-1, 1)
        def py(v): return cy + (v - vmin) / (vmax - vmin) * ch

        # Grid
        for i in range(5):
            gy = cy + i * ch / 4
            gv = vmin + i * (vmax - vmin) / 4
            c.setStrokeColor(hex(C['grid'])); c.setLineWidth(0.25)
            c.line(cx, gy, cx + cw, gy)
            c.setFillColor(hex(C['dim'])); c.setFont('Helvetica', 6)
            c.drawRightString(cx - 4, gy - 3, f'{gv:.1f}')

        # Lines + points
        for si, (lbl, pts) in enumerate(self.series):
            lcol = self.lcolors[si % len(self.lcolors)]
            valid = [(i, dt, v) for i, (dt, v) in enumerate(pts) if v is not None]
            if len(valid) < 2: continue

            c.setStrokeColor(hex(lcol)); c.setLineWidth(2.2)
            p = c.beginPath()
            p.moveTo(px(valid[0][0]), py(valid[0][2]))
            for i, dt, v in valid[1:]:
                p.lineTo(px(i), py(v))
            c.drawPath(p, stroke=1, fill=0)

            if self.show_points:
                for i, dt, v in valid:
                    c.setFillColor(hex(lcol))
                    c.circle(px(i), py(v), 3.5, fill=1, stroke=0)
                    c.setFillColor(hex(C['white'])); c.setFont('Helvetica-Bold', 6.5)
                    c.drawCentredString(px(i), py(v) + 6, f'{v:.1f}')

        # X labels
        _, first_pts = self.series[0]
        step = max(1, n // 8)
        c.setFillColor(hex(C['dim'])); c.setFont('Helvetica', 5.5)
        for i, (dt, _) in enumerate(first_pts):
            if i % step == 0 or i == len(first_pts)-1:
                c.drawCentredString(px(i), cy - 16, dt.strftime('%m/%y'))


# ── CHART: STACKED BARS (composizione corporea — stile InBody) ────────────────
class StackedBarChart(Flowable):
    """
    Barre verticali impilate per sessione: kg adipe (rosso) + kg magra (verde) = peso totale
    Ispirato ai report InBody Body Composition History
    """
    def __init__(self, sessions, width, height):
        super().__init__()
        self.sessions = sessions
        self.width    = width
        self.height   = height

    def draw(self):
        c = self.canv
        w, h = self.width, self.height
        PL, PR, PT, PB = 46, 14, 46, 32

        c.setFillColor(hex(C['bg']))
        c.roundRect(0, 0, w, h, 8, fill=1, stroke=0)

        cx = PL; cw = w - PL - PR
        cy = PB; ch = h - PT - PB

        ss = self.sessions
        n  = len(ss)

        # Valori
        adipe_vals  = [s['kg_adipe'] for s in ss]
        magra_vals  = [s['kg_magra'] for s in ss]
        totale_vals = [s['peso']     for s in ss]

        valid = [(i, a, m, t) for i, (a, m, t) in enumerate(zip(adipe_vals, magra_vals, totale_vals))
                 if a and m and t]
        if not valid: return

        # Scala: le barre impilate mostrano magra + adipe = totale
        # Il range Y va da 0 a max(totale)*1.08 così le proporzioni sono reali
        all_tot = [t for _, _, _, t in valid]
        vmax = max(all_tot) * 1.10
        vmin = 0  # partiamo da 0 così magra occupa proporzionalmente più spazio

        def px(i): return cx + (i + 0.5) * cw / n
        def py(v): return cy + v / vmax * ch
        bar_w = cw / n * 0.6

        # Title
        c.setFillColor(hex(C['white'])); c.setFont('Helvetica-Bold', 8.5)
        c.drawString(cx, h - 20, 'COMPOSIZIONE CORPOREA NEL TEMPO')

        # Colori: adipe=amber/giallo, magra=green, peso=white
        COL_ADIPE = '#F59E0B'   # amber
        COL_MAGRA = '#22C55E'   # green
        COL_PESO  = '#FFFFFF'   # white

        # Legenda
        leg = [('Kg Adipe', COL_ADIPE), ('Kg Massa Magra', COL_MAGRA), ('Peso tot.', COL_PESO)]
        for li, (lbl, col) in enumerate(leg):
            lx = cx + 8 + li * 85
            c.setFillColor(hex(col)); c.roundRect(lx, h-38, 10, 7, 2, fill=1, stroke=0)
            c.setFillColor(hex(C['sub'])); c.setFont('Helvetica', 6.5)
            c.drawString(lx + 13, h-37, lbl)

        # Y grid + labels
        for i in range(5):
            gy = cy + i * ch / 4
            gv = vmin + i * vmax / 4
            c.setStrokeColor(hex(C['grid'])); c.setLineWidth(0.25)
            c.line(cx, gy, cx + cw, gy)
            c.setFillColor(hex(C['dim'])); c.setFont('Helvetica', 6)
            c.drawRightString(cx - 4, gy - 3, f'{gv:.0f}')

        # Stacked bars — partono da 0, proporzioni reali
        for i, adipe, magra, totale in valid:
            x = px(i)

            # Kg magra — barra dal basso, occupa proporzionalmente molto più spazio
            y_base      = py(0)
            y_magra_top = py(magra)
            h_magra     = y_magra_top - y_base

            c.setFillColor(hex(COL_MAGRA))
            c.roundRect(x - bar_w/2, y_base, bar_w, h_magra, 3, fill=1, stroke=0)

            # Kg adipe — si impila sopra la magra
            y_adipe_bot = y_magra_top
            h_adipe     = py(totale) - y_magra_top
            c.setFillColor(hex(COL_ADIPE))
            c.roundRect(x - bar_w/2, y_adipe_bot, bar_w, h_adipe, 3, fill=1, stroke=0)

            # Linea peso totale — BIANCA come il grafico peso sopra
            if i > 0:
                _, _, _, t_prev = valid[i-1]
                c.setStrokeColor(hex(COL_PESO)); c.setLineWidth(2.2)
                c.line(px(valid[i-1][0]), py(t_prev), x, py(totale))

            c.setFillColor(hex(COL_PESO)); c.circle(x, py(totale), 3.5, fill=1, stroke=0)

            # Etichette valori dentro le barre
            c.setFont('Helvetica-Bold', 6.5)
            # Magra label dentro barra verde
            if h_magra > 14:
                c.setFillColor(hex(C['bg']))
                c.drawCentredString(x, y_base + h_magra/2 - 3, f'{magra:.1f}')
            # Adipe label dentro barra gialla
            if h_adipe > 10:
                c.setFillColor(hex(C['bg']))
                c.drawCentredString(x, y_adipe_bot + h_adipe/2 - 3, f'{adipe:.1f}')

            # X label data
            c.setFillColor(hex(C['dim'])); c.setFont('Helvetica', 5.5)
            c.drawCentredString(x, cy - 18, ss[i]['data'].strftime('%m/%y'))

        # Peso totale label sopra la barra
        for i, adipe, magra, totale in valid:
            c.setFillColor(hex(COL_PESO)); c.setFont('Helvetica-Bold', 6.5)
            c.drawCentredString(px(i), py(totale) + 6, f'{totale:.1f}')


# ── BUILD PDF ─────────────────────────────────────────────────────────────────
def build(data, out_path):
    ss  = data['sessions']
    ul  = data['ultima']

    # Stili ricorrenti
    s_th  = S('th',  'Helvetica-Bold', 7,   C['white'],  TA_CENTER, ld=9)
    s_th2 = S('th2', 'Helvetica',      6,   '#94A3B8',   TA_CENTER, ld=8)
    s_tv  = S('tv',  'Helvetica',      7.5, C['white'],  TA_CENTER, ld=9)
    s_tvB = S('tvB', 'Helvetica-Bold', 7.5, C['white'],  TA_CENTER, ld=9)
    s_td  = S('td',  'Helvetica',      7,   C['sub'],    TA_LEFT,   ld=9)
    s_sec = S('sec', 'Helvetica-Bold', 9.5, C['green'],  ld=12, sa=4, sb=6)
    s_sub = S('sub', 'Helvetica',      8.5, C['sub'],    ld=11)
    s_g   = S('g',   'Helvetica-Bold', 8.5, C['sub'],    ld=11, sa=3, sb=5)

    def dp(v, inv=False): return dpara(v, s_tv, inv)

    # ── PAGE CALLBACKS ──
    def page_portrait(c, doc):
        c.saveState()
        c.setFillColor(hc('bg')); c.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
        c.setFillColor(hc('panel')); c.rect(0, 0, A4[0], 1.1*cm, fill=1, stroke=0)
        c.setFillColor(hc('green')); c.rect(0, 1.08*cm, A4[0], 2, fill=1, stroke=0)
        c.setFillColor(hc('sub')); c.setFont('Helvetica', 6.5)
        c.drawCentredString(A4[0]/2, 0.38*cm, 'Nutrizionista Elena Toschi - 3664977229')
        c.setFont('Helvetica-Bold', 6.5); c.setFillColor(hc('green'))
        c.drawRightString(A4[0]-1.2*cm, 0.38*cm, f'pag. {doc.page}')
        c.restoreState()

    def page_landscape(c, doc):
        W, H = landscape(A4)
        c.saveState()
        c.setFillColor(hc('bg')); c.rect(0, 0, W, H, fill=1, stroke=0)
        c.setFillColor(hc('panel')); c.rect(0, 0, W, 1.1*cm, fill=1, stroke=0)
        c.setFillColor(hc('green')); c.rect(0, 1.08*cm, W, 2, fill=1, stroke=0)
        c.setFillColor(hc('sub')); c.setFont('Helvetica', 6.5)
        c.drawCentredString(W/2, 0.38*cm, 'Nutrizionista Elena Toschi - 3664977229')
        c.setFont('Helvetica-Bold', 6.5); c.setFillColor(hc('green'))
        c.drawRightString(W-1.0*cm, 0.38*cm, f'pag. {doc.page}')
        c.restoreState()

    # ── HEADER BLOCK (riusato su ogni pagina) ──
    def make_header(landscape_mode=False):
        data_str = ul['data'].strftime('%d/%m/%Y')
        forma_hex = C['green'] if ul['forma'] in ('Atleta','Forma buona') else C['amber']
        tbl = Table([
            [Paragraph(data['nome'], S('nm','Helvetica-Bold',21,C['white']))],
            [Paragraph(
                f'Ultima visita: <b>{data_str}</b>  ·  '
                f'Età: <b>{data["eta"]}</b> anni  ·  H: <b>{data["altezza"]}</b> cm  ·  BMI: <b>{ul["bmi"]}</b>'
                f'  ·  Forma fisica: <b><font color="{forma_hex}">{ul["forma"]}</font></b>',
                s_sub)],
        ], colWidths=[None])
        tbl.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), hc('panel')),
            ('LEFTPADDING', (0,0), (-1,-1), 14), ('RIGHTPADDING', (0,0), (-1,-1), 14),
            ('TOPPADDING', (0,0), (-1,-1), 12), ('BOTTOMPADDING', (0,0), (-1,-1), 12),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ]))
        return tbl

    # ════════════════════════════════════════════════════════════════════════
    # STRUTTURA NUOVA:
    # PAG 1 — Header + KPI + Tabella ref + STORICO MISURAZIONI + Grafico Peso + Grafico Composizione
    # PAG 2 — Plicometrie + Circonferenze + Grafico Circonferenze + Grafico Plicometrie
    from io import BytesIO

    buf_p = BytesIO()
    doc_p = SimpleDocTemplate(buf_p, pagesize=A4,
        leftMargin=1.2*cm, rightMargin=1.2*cm,
        topMargin=1.4*cm, bottomMargin=1.6*cm)

    CW_P = A4[0] - 2*1.2*cm   # ~18.6 cm
    story_p = []

    # ─── PAG 1 ────────────────────────────────────────────────────────────
    story_p.append(make_header())
    story_p.append(HRFlowable(width='100%', thickness=2.5, color=hc('green'), spaceAfter=8))

    # KPI
    kpis = [
        (fv(ul['peso']),         'PESO (kg)',         C['green']),
        (f'{ul["fm_pct"]:.1f}%', '% MASSA GRASSA',   C['amber']),
        (fv(ul['kg_magra']),     'MASSA MAGRA (kg)',  C['blue']),
        (fv(ul['kg_adipe']),     'KG ADIPE',          C['rose']),
        (str(ul['bmi']) if ul['bmi'] else '–', 'BMI', C['sub']),
    ]
    kpi_row = [[
        Paragraph(v, S(f'kv{i}','Helvetica-Bold',16,col,TA_CENTER,ld=18)),
        Paragraph(l, S(f'kl{i}','Helvetica',6.5,C['sub'],TA_CENTER,ld=9))
    ] for i,(v,l,col) in enumerate(kpis)]
    kpi_t = Table([kpi_row], colWidths=[CW_P/5]*5)
    kpi_t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,-1),hc('panel')),
        ('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('LINEAFTER',(0,0),(3,0),0.4,hc('border')),
        ('BOX',(0,0),(-1,-1),0.4,hc('border')),
    ]))
    story_p.append(kpi_t)
    story_p.append(Spacer(1, 8))

    # Tabella riferimento FM%
    genere_label = data.get('genere', 'UOMO')
    soglie = data.get('soglie_fm', {})
    story_p.append(Paragraph(
        f'TABELLA DI RIF. — FORMA CORPOREA FM% PER ETÀ ({genere_label})',
        S('rt','Helvetica-Bold',7.5,C['sub'],ld=9,sa=3)))

    def pct_str(v): return f'{v:.0f}%'

    # Scala di colori per riga % — 6 tonalità crescenti (chiaro→scuro)
    # Rosa per DONNA, Azzurro per UOMO
    if genere_label == 'DONNA':
        SCALE_COLORS = [
            ('#FFE4EE', '#111827'),  # grasso ess. — rosa chiarissimo
            ('#FFBDD4', '#111827'),  # atleta
            ('#FF91B8', '#111827'),  # forma buona
            ('#FF619A', '#111827'),  # accettabile
            ('#E8366E', '#FFFFFF'),  # sovrappeso
            ('#A8003E', '#FFFFFF'),  # obesità
        ]
    else:
        SCALE_COLORS = [
            ('#DBEFFF', '#111827'),  # grasso ess. — azzurro chiarissimo
            ('#AACFEE', '#111827'),  # atleta
            ('#73AADC', '#111827'),  # forma buona
            ('#3D82C4', '#FFFFFF'),  # accettabile
            ('#1A5CA0', '#FFFFFF'),  # sovrappeso
            ('#0C3468', '#FFFFFF'),  # obesità
        ]

    if soglie:
        s_ess = soglie['essenziale']; s_atl = soglie['atleta']
        s_buo = soglie['buona'];      s_acc = soglie['accettabile']; s_sov = soglie['sovrappeso']
        REF = [
            ('Grasso ess.',  SCALE_COLORS[0], f'<{pct_str(s_ess)}'),
            ('Atleta',       SCALE_COLORS[1], f'{pct_str(s_ess)}-{pct_str(s_atl)}'),
            ('Forma buona',  SCALE_COLORS[2], f'{pct_str(s_atl)}-{pct_str(s_buo)}'),
            ('Accettabile',  SCALE_COLORS[3], f'{pct_str(s_buo)}-{pct_str(s_acc)}'),
            ('Sovrappeso',   SCALE_COLORS[4], f'{pct_str(s_acc)}-{pct_str(s_sov)}'),
            ('Obesità',      SCALE_COLORS[5], f'>{pct_str(s_sov)}'),
        ]
        def get_categoria(fm):
            if fm < s_ess: return 'Grasso ess.'
            if fm < s_atl: return 'Atleta'
            if fm < s_buo: return 'Forma buona'
            if fm < s_acc: return 'Accettabile'
            if fm < s_sov: return 'Sovrappeso'
            return 'Obesità'
    else:
        REF = [
            ('Grasso ess.',  SCALE_COLORS[0], '3-4%'),
            ('Atleta',       SCALE_COLORS[1], '5-13%'),
            ('Forma buona',  SCALE_COLORS[2], '13-16%'),
            ('Accettabile',  SCALE_COLORS[3], '16-22%'),
            ('Sovrappeso',   SCALE_COLORS[4], '22-28%'),
            ('Obesità',      SCALE_COLORS[5], '28%+'),
        ]
        def get_categoria(fm):
            if fm < 5:   return 'Grasso ess.'
            if fm < 13:  return 'Atleta'
            if fm < 16:  return 'Forma buona'
            if fm < 22:  return 'Accettabile'
            if fm < 28:  return 'Sovrappeso'
            return 'Obesità'

    fm_cur = ul['fm_pct']
    cat_cur = get_categoria(fm_cur)
    n_ref = len(REF)
    ref_cw = [1.5*cm] + [(CW_P-1.5*cm)/n_ref]*n_ref
    ref_hdr = [Paragraph('', s_th)] + [
        Paragraph(lbl, S(f'rh{i}','Helvetica-Bold',6.5,tc,TA_CENTER,ld=8))
        for i,(lbl,(bg,tc),rng) in enumerate(REF)]
    ref_row = [Paragraph(genere_label.title(), S('ru','Helvetica',6.5,C['sub'],TA_LEFT,ld=9))] + [
        Paragraph(f'<b>{rng}</b>' if lbl==cat_cur else rng,
            S(f'rv{i}','Helvetica-Bold' if lbl==cat_cur else 'Helvetica',
              7 if lbl==cat_cur else 6.5, tc, TA_CENTER, ld=8))
        for i,(lbl,(bg,tc),rng) in enumerate(REF)]
    ref_t = Table([ref_hdr, ref_row], colWidths=ref_cw)
    ref_ts = [
        ('BACKGROUND',(0,0),(-1,0),hc('panel')),
        ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
        ('LEFTPADDING',(0,0),(-1,-1),3),
        ('GRID',(0,0),(-1,-1),0.2,hc('border')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
    ]
    for ci,(lbl,(bg,tc),_) in enumerate(REF):
        ref_ts.append(('BACKGROUND',(ci+1,0),(ci+1,0),hex(bg)))
        ref_ts.append(('BACKGROUND',(ci+1,1),(ci+1,1),hex(bg)))
        if lbl == cat_cur:
            ref_ts.append(('BOX',(ci+1,0),(ci+1,1),1.5,hc('green')))
    ref_t.setStyle(TableStyle(ref_ts))
    story_p.append(ref_t)
    story_p.append(Spacer(1, 8))

    # ── STORICO MISURAZIONI — struttura:
    # DATA | PESO(Kg) [val Δprec Δtot] | MASSA MAGRA: %(val) + Kg(val Δprec Δtot) | MASSA GRASSA: %(val) + Kg(val Δprec Δtot)
    # = 1 + 3 + 1+3 + 1+3 = 12 colonne
    # Col index:
    #  0=DATA
    #  1=PESO val+u, 2=PESO Δprec, 3=PESO Δtot
    #  4=MM%, 5=MM Kg val, 6=MM Δprec, 7=MM Δtot
    #  8=MG%, 9=MG Kg val, 10=MG Δprec, 11=MG Δtot

    # Larghezza totale storico = larghezza tabella riferimento FM%
    W_REF_TABLE = sum(ref_cw)
    # Proporzioni colonne (base)
    _BASE_RATIOS = [1.6, 1.6, 0.9, 0.9,   # DATA + PESO
                    1.1, 1.4, 0.9, 0.9,   # MASSA MAGRA
                    1.1, 1.4, 0.9, 0.9]   # MASSA GRASSA
    _BASE_TOT = sum(_BASE_RATIOS)
    sto_cw = [r / _BASE_TOT * W_REF_TABLE for r in _BASE_RATIOS]

    # Colori header storico
    COL_PESO_BG    = '#FFFFFF'  # bianco
    COL_PESO_FG    = '#111827'  # nero
    COL_MM_BG      = '#F59E0B'  # amber = colore "Kg Adipe" nel grafico composizione
    COL_MG_BG      = '#22C55E'  # green = colore "Kg Massa Magra" nel grafico composizione
    COL_MM_FG      = '#111827'  # testo scuro su sfondo chiaro/caldo
    COL_MG_FG      = '#0F172A'  # testo scuro su sfondo verde

    # Header riga 1: macro-colonne
    # PESO span 1-3, MASSA MAGRA span 4-7, MASSA GRASSA span 8-11
    s_th_peso  = S('thp', 'Helvetica-Bold', 7, COL_PESO_FG, TA_CENTER, ld=9)
    s_th_mm    = S('thmm','Helvetica-Bold', 7, COL_MM_FG,   TA_CENTER, ld=9)
    s_th_mg    = S('thmg','Helvetica-Bold', 7, COL_MG_FG,   TA_CENTER, ld=9)
    sto_h1 = [
        Paragraph('', s_th),
        Paragraph('PESO (Kg)', s_th_peso), Paragraph('', s_th_peso), Paragraph('', s_th_peso),
        Paragraph('MASSA MAGRA', s_th_mm), Paragraph('', s_th_mm), Paragraph('', s_th_mm), Paragraph('', s_th_mm),
        Paragraph('MASSA GRASSA', s_th_mg), Paragraph('', s_th_mg), Paragraph('', s_th_mg), Paragraph('', s_th_mg),
    ]
    # Header riga 2: sub-colonne
    s_th2s = S('th2s','Helvetica',6,C['sub'],TA_CENTER,ld=8)
    sto_h2 = [
        Paragraph('DATA', s_th),
        Paragraph('val. (Kg)', s_th2s), Paragraph('diff. da\nprec.', s_th2s), Paragraph('diff.\ntot', s_th2s),
        Paragraph('%', s_th2s), Paragraph('Kg', s_th2s), Paragraph('diff. da\nprecedente', s_th2s), Paragraph('diff.\nTot', s_th2s),
        Paragraph('%', s_th2s), Paragraph('Kg', s_th2s), Paragraph('diff. da\nprecedente', s_th2s), Paragraph('diff.\nTot', s_th2s),
    ]
    sto_spans = [
        ('SPAN',(1,0),(3,0)),   # PESO
        ('SPAN',(4,0),(7,0)),   # MASSA MAGRA
        ('SPAN',(8,0),(11,0)),  # MASSA GRASSA
    ]

    s_tvB_last = S('tvBL','Helvetica-Bold',7,'#111827',TA_CENTER,ld=8)
    s_tv_last  = S('tvL','Helvetica',6.5,'#111827',TA_CENTER,ld=8)

    sto_rows = [sto_h1, sto_h2]
    for ri, s in enumerate(ss):
        is_last = (ri == len(ss)-1)
        td_s  = S(f'std{ri}','Helvetica',6.5,'#111827' if is_last else C['sub'],TA_LEFT,ld=8)
        tvB_s = s_tvB_last if is_last else S(f'stvB{ri}','Helvetica-Bold',7,C['white'],TA_CENTER,ld=8)
        tv_s  = s_tv_last  if is_last else S(f'stv{ri}','Helvetica',6.5,C['white'],TA_CENTER,ld=8)
        prev  = ss[ri-1] if ri > 0 else None

        def dp_prec(cur, prv, inv=False):
            if prv is None or cur is None: return Paragraph('–', tv_s)
            try: return dpara(round(float(cur)-float(prv),1), tv_s, inv)
            except: return Paragraph('–', tv_s)

        peso   = s['peso'];          pp  = prev['peso']          if prev else None
        mm_kg  = s['kg_magra'];      pm  = prev['kg_magra']      if prev else None
        mm_pct = s['kg_magra_pct'];
        mg_kg  = s['kg_adipe'];      pa  = prev['kg_adipe']      if prev else None
        mg_pct = s['kg_adipe_pct'];

        row = [
            Paragraph(s['data'].strftime('%d/%m/%y'), td_s),
            # PESO
            Paragraph(fv(peso)+' Kg', tvB_s),
            dp_prec(peso, pp),
            dpara(s.get('dtot_peso'), tv_s),
            # MASSA MAGRA: % | Kg val | Kg Δprec | Kg Δtot
            Paragraph(fv(mm_pct)+'%', tvB_s),
            Paragraph(fv(mm_kg)+' Kg', tvB_s),
            dp_prec(mm_kg, pm, inv=True),
            dpara(s.get('dtot_mg'), tv_s, True),
            # MASSA GRASSA: % | Kg val | Kg Δprec | Kg Δtot
            Paragraph(fv(mg_pct)+'%', tvB_s),
            Paragraph(fv(mg_kg,2)+' Kg', tvB_s),
            dp_prec(mg_kg, pa),
            dpara(s.get('dtot_adipe'), tv_s),
        ]
        sto_rows.append(row)

    sto_ts = [
        ('BACKGROUND',(0,0),(-1,1),hc('panel')),
        ('ROWBACKGROUNDS',(0,2),(-1,-1),[hc('panel'),hc('panel2')]),
        ('BACKGROUND',(0,-1),(-1,-1),hex('#FFFFFF')),
        ('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2),
        ('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2),
        ('GRID',(0,0),(-1,-1),0.15,hc('border')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(0,0),(-1,-1),'CENTER'),
        # Separatori macro-colonne
        ('LINEBEFORE',(1,0),(1,-1),1.0,hex(COL_PESO_BG)),
        ('LINEBEFORE',(4,0),(4,-1),1.0,hex(COL_MM_BG)),
        ('LINEBEFORE',(8,0),(8,-1),1.0,hex(COL_MG_BG)),
        # Separatore % / Kg dentro MM e MG
        ('LINEBEFORE',(5,1),(5,-1),0.4,hc('border')),
        ('LINEBEFORE',(9,1),(9,-1),0.4,hc('border')),
        # Sfondo header macro: PESO bianco, MM amber, MG verde
        ('BACKGROUND',(1,0),(3,0),hex(COL_PESO_BG)),
        ('BACKGROUND',(4,0),(7,0),hex(COL_MM_BG)),
        ('BACKGROUND',(8,0),(11,0),hex(COL_MG_BG)),
    ] + sto_spans
    sto_t = Table(sto_rows, colWidths=sto_cw)
    sto_t.setStyle(TableStyle(sto_ts))

    # ── GRAFICI PAG 1 ──
    def pts(key): return [(s['data'], s[key]) for s in ss]
    def pts_tpl(key): return [(s['data'], s[key][0]) for s in ss if s[key][0]]

    n_sess = len(ss)

    # Titolo storico + tabella a tutta larghezza
    story_p.append(Paragraph('STORICO MISURAZIONI',
        S('stit2b','Helvetica-Bold',9.5,C['green'],ld=12,sa=3,sb=6)))
    story_p.append(Paragraph(
        'Peso · Massa Magra (Kg e %) · Massa Grassa (Kg e %)  —  Δ dalla visita precedente e dalla prima',
        S('sleg2b','Helvetica-Oblique',7,C['sub'],ld=9,sa=4)))
    story_p.append(sto_t)
    story_p.append(Spacer(1, 10))

    # Solo grafico COMPOSIZIONE — larghezza uguale alla tabella di riferimento
    H_COMP = min(12.0*cm, max(8.0*cm, 2.0*cm + n_sess * 1.8*cm))
    story_p.append(StackedBarChart(ss, W_REF_TABLE, H_COMP))

    # ─── PAG 2: PLICOMETRIE + CIRCONFERENZE + GRAFICI ─────────────────────
    story_p.append(PageBreak())
    story_p.append(make_header())
    story_p.append(HRFlowable(width='100%', thickness=2.5, color=hc('green'), spaceAfter=8))

    # PLICOMETRIE
    story_p.append(Paragraph('PLICOMETRIE (mm)', s_sec))
    PLIC = [('Petto','petto'),('Tricipite','tricipite'),('Ascella','ascella'),
            ('Scapola','scapola'),('Soprailiaca','soprailiaca'),('Addominale','addominale'),('Coscia','coscia_p')]
    p_cw = [1.8*cm] + [(CW_P-1.8*cm)/14]*14
    W_PLIC_TABLE = sum(p_cw)
    p_hdr1 = [Paragraph('', s_th)] + [
        x for nm,_ in PLIC
        for x in [Paragraph(nm, s_th), Paragraph('', s_th)]]
    p_hdr2 = [Paragraph('DATA', s_th)] + [
        x for _ in PLIC for x in [Paragraph('mm', s_th2), Paragraph('Δ tot.', s_th2)]]
    spans_p = [('SPAN',(1+i*2,0),(2+i*2,0)) for i in range(7)]
    p_rows = [p_hdr1, p_hdr2]
    for ri, s in enumerate(ss):
        is_last = (ri == len(ss)-1)
        td_s  = S(f'ptd{ri}','Helvetica',7,'#111827' if is_last else C['sub'],TA_LEFT,ld=9)
        tvB_s = s_tvB_last if is_last else s_tvB
        tv_s  = s_tv_last  if is_last else s_tv
        row = [Paragraph(s['data'].strftime('%d/%m/%y'), td_s)]
        for _, k in PLIC:
            v, d_p = s[k]; row += [Paragraph(fv(v), tvB_s), dpara(d_p, tv_s)]
        p_rows.append(row)
    p_ts = [
        ('BACKGROUND',(0,0),(-1,1),hc('panel')),
        ('ROWBACKGROUNDS',(0,2),(-1,-1),[hc('panel'),hc('panel2')]),
        ('BACKGROUND',(0,-1),(-1,-1),hex('#FFFFFF')),
        ('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2),
        ('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2),
        ('GRID',(0,0),(-1,-1),0.15,hc('border')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(0,0),(-1,-1),'CENTER'),
    ] + spans_p
    p_t = Table(p_rows, colWidths=p_cw)
    p_t.setStyle(TableStyle(p_ts))
    story_p.append(p_t)
    story_p.append(Spacer(1, 8))

    # CIRCONFERENZE — donna: no torace, sì coscia alta/media/bassa
    story_p.append(Paragraph('CIRCONFERENZE (cm)', s_sec))
    is_donna = genere_label == 'DONNA'
    if is_donna:
        CIRC = [('Collo','collo'),('Br.ril.','br_ril'),('Br.con.','br_con'),
                ('Vita','vita'),('Add.','add_basso'),('Fianchi','fianchi'),
                ('C.alta','cos_alta'),('C.med.','cos_media'),('C.bassa','cos_bassa'),('Polp.','polpaccio')]
    else:
        CIRC = [('Collo','collo'),('Torace','torace'),('Br.ril.','br_ril'),('Br.con.','br_con'),
                ('Vita','vita'),('Add.','add_basso'),('Fianchi','fianchi'),
                ('Coscia','cos_media'),('Polpaccio','polpaccio')]
    n_circ = len(CIRC)
    c_cw = [1.8*cm] + [(CW_P-1.8*cm)/(n_circ*2)]*(n_circ*2)
    W_CIRC_TABLE = sum(c_cw)
    c_hdr1 = [Paragraph('', s_th)] + [
        x for nm,_ in CIRC
        for x in [Paragraph(nm, S(f'ch{nm}','Helvetica-Bold',6,C['white'],TA_CENTER,ld=8)), Paragraph('', s_th)]]
    c_hdr2 = [Paragraph('DATA', s_th)] + [
        x for _ in CIRC for x in [Paragraph('cm', s_th2), Paragraph('Δ tot.', s_th2)]]
    spans_c = [('SPAN',(1+i*2,0),(2+i*2,0)) for i in range(n_circ)]
    c_rows = [c_hdr1, c_hdr2]
    for ri, s in enumerate(ss):
        is_last = (ri == len(ss)-1)
        td_s  = S(f'ctd{ri}','Helvetica',7,'#111827' if is_last else C['sub'],TA_LEFT,ld=9)
        tvB_s = s_tvB_last if is_last else s_tvB
        tv_s  = s_tv_last  if is_last else s_tv
        row = [Paragraph(s['data'].strftime('%d/%m/%y'), td_s)]
        for _, k in CIRC:
            v, d_c = s[k]; row += [Paragraph(fv(v), tvB_s), dpara(d_c, tv_s)]
        c_rows.append(row)
    c_ts = [
        ('BACKGROUND',(0,0),(-1,1),hc('panel')),
        ('ROWBACKGROUNDS',(0,2),(-1,-1),[hc('panel'),hc('panel2')]),
        ('BACKGROUND',(0,-1),(-1,-1),hex('#FFFFFF')),
        ('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2),
        ('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2),
        ('GRID',(0,0),(-1,-1),0.15,hc('border')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(0,0),(-1,-1),'CENTER'),
    ] + spans_c
    c_t = Table(c_rows, colWidths=c_cw)
    c_t.setStyle(TableStyle(c_ts))
    story_p.append(c_t)
    story_p.append(Spacer(1, 8))

    # GRAFICO PLICOMETRIE — larghezza = tabella pliche, altezza raddoppiata
    H_PLIC = 9.0*cm
    story_p.append(LineChart(
        [('Addominale (mm)', pts_tpl('addominale')),
         ('Soprailiaca (mm)', pts_tpl('soprailiaca'))],
        W_PLIC_TABLE, H_PLIC, 'GRAFICO PLICOMETRIE — Addominale e Soprailiaca (mm)',
        line_colors=[C['amber'], C['violet']]
    ))
    story_p.append(Spacer(1, 10))

    # GRAFICO CIRCONFERENZE — larghezza = tabella circ, altezza raddoppiata
    H_CIRC = 9.0*cm
    story_p.append(LineChart(
        [('Vita (cm)', pts_tpl('vita')),
         ('Addome basso (cm)', pts_tpl('add_basso'))],
        W_CIRC_TABLE, H_CIRC, 'GRAFICO CIRCONFERENZE — Vita e Addome (cm)',
        line_colors=[C['blue'], C['rose']]
    ))

    doc_p.build(story_p, onFirstPage=page_portrait, onLaterPages=page_portrait)

    # ── Scrivi il PDF finale (tutto portrait) ──
    with open(out_path, 'wb') as f:
        f.write(buf_p.getvalue())

    print(f'✅  {out_path}')

# ── MAIN ─────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import sys, os, warnings
    warnings.filterwarnings('ignore')

    if len(sys.argv) > 1:
        # Uso da riga di comando: python script.py percorso/file.xlsx
        excel_path = sys.argv[1]
    else:
        # Nessun argomento → apri dialogo grafico di selezione file (Esplora Risorse)
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()                    # nasconde la finestra vuota di Tk
            root.attributes('-topmost', True)  # porta il dialogo in primo piano
            excel_path = filedialog.askopenfilename(
                title='Seleziona il file Excel del cliente',
                filetypes=[('File Excel', '*.xlsx *.xlsm'), ('Tutti i file', '*.*')],
            )
            root.destroy()
            if not excel_path:
                print('❌  Nessun file selezionato. Uscita.')
                sys.exit(0)
        except Exception as e:
            print(f'❌  Impossibile aprire il dialogo grafico: {e}')
            print('   Usa: python script.py percorso/file.xlsx')
            sys.exit(1)

    if not os.path.isfile(excel_path):
        print(f'❌  File non trovato: {excel_path}')
        sys.exit(1)

    # Il PDF viene salvato nella stessa cartella del file Excel
    base     = os.path.splitext(excel_path)[0]
    out_path = base + '_Report.pdf'

    print(f'📂  Input : {excel_path}')
    print(f'📄  Output: {out_path}')

    d = load_data(excel_path)
    print(f'👤  Cliente : {d["nome"]}  |  Genere: {d["genere"]}  |  Sessioni: {len(d["sessions"])}')
    build(d, out_path)
    print(f'\n✅  Report generato: {out_path}')
