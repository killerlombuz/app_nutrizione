"""
╔══════════════════════════════════════════════════════════════════════╗
║        GENERATORE PIANO NUTRIZIONALE PDF — Elena Toschi v25         ║
║  Legge automaticamente il foglio "Dieta 2all." di un file Excel     ║
║  e genera un PDF multi-pagina con la grafica Carbon.                ║
╠══════════════════════════════════════════════════════════════════════╣
║  VERSIONE 25 - BASE v24 + FIX ORDINE SEZIONI:                      ║
║  • Spuntino Pomeriggio ora appare PRIMA della Cena (ordine          ║
║    corretto: Colazione → Sp.Mattina → Pranzo → Sp.Pomeriggio → Cena)║
╠══════════════════════════════════════════════════════════════════════╣
║  USO:                                                               ║
║    python3 MODELLO_genera_piano_nutrizionale_v23.py /percorso/file.xlsx ║
║    oppure importa e chiama: genera_pdf("/percorso/file.xlsx")        ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import sys
import os
import datetime
import openpyxl
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

W, H = A4

# ─────────────────────────────────────────────────────────────────────────────
# PALETTE
# ─────────────────────────────────────────────────────────────────────────────
DARK        = colors.HexColor("#1A1A2E")
ACCENT      = colors.HexColor("#16213E")
GREEN       = colors.HexColor("#2ECC71")
GREEN_DARK  = colors.HexColor("#27AE60")
GREEN_BG    = colors.HexColor("#E8F8F0")
TEAL        = colors.HexColor("#1ABC9C")
TEAL_BG     = colors.HexColor("#E8FAF5")
ORANGE      = colors.HexColor("#E67E22")
ORANGE_BG   = colors.HexColor("#FEF5EB")
BROWN       = colors.HexColor("#7D5A3C")
PURPLE      = colors.HexColor("#9B59B6")
PURPLE_BG   = colors.HexColor("#F5EEF8")
BLUE        = colors.HexColor("#3498DB")
BLUE_BG     = colors.HexColor("#EBF5FB")
RED         = colors.HexColor("#E74C3C")
GRAY_LIGHT  = colors.HexColor("#F8F9FA")
GRAY_MID    = colors.HexColor("#DEE2E6")
GRAY_TEXT   = colors.HexColor("#6C757D")
WHITE       = colors.white
KCAL_TEXT   = colors.HexColor("#F9E79F")
PROT_COLOR  = colors.HexColor("#8E44AD")

# ─────────────────────────────────────────────────────────────────────────────
# EXCEL READER
# ─────────────────────────────────────────────────────────────────────────────
ERRORS = {'#N/A', '#REF!', '#NUM!', '#VALUE!', '#DIV/0!', '#NAME?', '#NULL!'}

# All training-variant colors are now VALID values to read:
# FF0070C0 = blue  = valore allenamento sport 1
# FF008E40 = green = valore allenamento sport 2
# These are NOT hidden — they carry real gram/kcal values.
# Only truly hidden: theme=1 white-on-white (handled by value filtering, not color).
_HIDDEN_COLORS = set()  # nothing is hidden by color in this workbook

def _is_strikethrough(cell):
    """Return True if the cell has strikethrough formatting (font.strike=True).
    Strikethrough is used by the nutritionist to mark content that must NOT appear in the PDF."""
    return bool(cell.font and cell.font.strike)

def is_visible(cell):
    val = cell.value
    if val is None:
        return False
    s = str(val).strip()
    if s in ERRORS or s == '':
        return False
    if _is_strikethrough(cell):
        return False
    fc = cell.font.color if cell.font else None
    if fc and fc.type == 'rgb' and fc.rgb in _HIDDEN_COLORS:
        return False
    return True

def cv(cell):
    """Return clean string value of a cell, or '' if it's an error/hidden/strikethrough."""
    val = cell.value
    if val is None:
        return ''
    s = str(val).strip()
    if s in ERRORS or s == '':
        return ''
    if _is_strikethrough(cell):
        return ''
    fc = cell.font.color if cell.font else None
    if fc and fc.type == 'rgb' and fc.rgb in _HIDDEN_COLORS:
        return ''
    if isinstance(val, datetime.datetime):
        return val.strftime('%d/%m/%Y')
    return s

def num(cell):
    """Return numeric value or None (None also for errors/hidden/strikethrough)."""
    val = cell.value
    if val is None:
        return None
    if str(val).strip() in ERRORS:
        return None
    if _is_strikethrough(cell):
        return None
    fc = cell.font.color if cell.font else None
    if fc and fc.type == 'rgb' and fc.rgb in _HIDDEN_COLORS:
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        return None

def fmt_g(value):
    """Format grams: integer if whole, else 1 decimal."""
    if value is None:
        return ''
    v = float(value)
    return str(int(v)) if v == int(v) else f"{v:.1f}"

def fmt_prot(p):
    """Round protein to integer."""
    if p is None:
        return ''
    return str(int(round(float(p))))


def read_excel(path):
    """
    Read the Excel file and return a structured dict with all plan data.
    Sezioni rilevate per keyword — funziona indipendentemente dalla posizione delle righe.
    Testo bianco (FFFFFFFF) ignorato automaticamente.
    """
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb['Dieta 2all.']

    d = {}

    # ── HELPER: is_visible con filtro testo bianco e barrato ─────────────────
    def _cell_visible(cell):
        val = cell.value
        if val is None: return False
        s = str(val).strip()
        if s in ERRORS or s == '': return False
        if cell.font and cell.font.strike: return False          # barrato → nascosto
        fc = cell.font.color if cell.font else None
        if fc and fc.type == 'rgb' and fc.rgb == 'FFFFFFFF': return False
        return True

    def _cv(cell):
        if not _cell_visible(cell): return ''
        val = cell.value
        if isinstance(val, datetime.datetime): return val.strftime('%d/%m/%Y')
        return str(val).strip()

    # ── KEYWORD SECTION FINDER ────────────────────────────────────────────────
    SECTION_KEYS = {
        'COLAZIONE': None, 'SPUNTINO MATTINA': None, 'PRANZO': None,
        'SPUNTINO POMERIGGIO': None, 'CENA': None,
    }
    # COLAZIONE, PRANZO, CENA: keyword esatta
    for row in range(1, 220):
        for col in range(1, 25):
            cell = ws.cell(row=row, column=col)
            if not _cell_visible(cell): continue
            s = str(cell.value).strip().upper()
            for key in ('COLAZIONE', 'PRANZO', 'CENA'):
                if (s == key or s.startswith(key + ' ')) and SECTION_KEYS[key] is None:
                    SECTION_KEYS[key] = (row, col)
    # SPUNTINI: trovati per posizione (1° = mattina, 2° = pomeriggio/sera).
    # Il testo reale viene letto dalla cella H della riga trovata e usato
    # direttamente come label nel PDF — nessun hardcoding di nomi.
    spuntini_trovati = []
    for row in range(1, 220):
        for col in range(1, 25):
            cell = ws.cell(row=row, column=col)
            if not _cell_visible(cell): continue
            s = str(cell.value).strip().upper()
            if s.startswith('SPUNTINO'):
                spuntini_trovati.append((row, col))
                break  # una sola occorrenza per riga
    spuntini_trovati.sort(key=lambda x: x[0])
    if len(spuntini_trovati) >= 1:
        SECTION_KEYS['SPUNTINO MATTINA'] = spuntini_trovati[0]
    if len(spuntini_trovati) >= 2:
        SECTION_KEYS['SPUNTINO POMERIGGIO'] = spuntini_trovati[1]

    def _sec(name): return SECTION_KEYS.get(name)

    # Helper: legge kcal e proteine dalle celle fisse per ogni sezione
    # Struttura comune: kcal_norm=L, kcal_all1=M, kcal_all2=N (o M/N per colazione)
    # proteine: prot_min=P (o O), prot_max=Q (o P)
    # La label 'proteine' è sempre nell'ultima colonna (R o Q)
    from openpyxl.utils import column_index_from_string as col_idx

    def _read_section_header(kcal_norm_cell, kcal_all1_cell, kcal_all2_cell,
                              prot_min_cell, prot_max_cell):
        """
        Legge kcal (normale / all1 / all2) e proteine (min / max) dalle celle indicate.
        Ritorna (kcal_str, prot_str) già formattate per l'header.
        kcal_str: es. '810–1460 kcal' oppure '320 kcal'
        prot_str: es. '70–98 g proteine'
        """
        def _n(cell_ref):
            """Legge un valore numerico da un riferimento 'R{row}C{col}' o cella openpyxl."""
            if cell_ref is None: return None
            v = cell_ref.value
            if v is None: return None
            if str(v).strip() in ERRORS: return None
            if cell_ref.font and cell_ref.font.strike: return None
            try: return float(v)
            except (TypeError, ValueError): return None

        kn  = _n(kcal_norm_cell)
        ka1 = _n(kcal_all1_cell)
        ka2 = _n(kcal_all2_cell)
        pm  = _n(prot_min_cell)
        pM  = _n(prot_max_cell)

        # kcal string: mostra range solo se i valori sono davvero diversi
        kcal_parts = [v for v in [kn, ka1, ka2] if v is not None and v > 0]
        if not kcal_parts:
            kcal_str = ''
        else:
            kcal_min = int(min(kcal_parts))
            kcal_max = int(max(kcal_parts))
            if kcal_min == kcal_max:
                kcal_str = f"{kcal_min} kcal"
            else:
                kcal_str = f"{kcal_min}\u2013{kcal_max} kcal"

        # prot string
        if pm and pM and abs(pm - pM) > 0.5:
            prot_str = f"{fmt_prot(pm)}\u2013{fmt_prot(pM)} g proteine"
        elif pm and pm > 0:
            prot_str = f"{fmt_prot(pm)} g proteine"
        elif pM and pM > 0:
            prot_str = f"{fmt_prot(pM)} g proteine"
        else:
            prot_str = ''

        return kcal_str, prot_str

    # ── CLIENT INFO ──────────────────────────────────────────────────────────
    ws_mis = wb['Misure']
    d['nome'] = str(ws_mis['I1'].value).strip() if ws_mis['I1'].value else (_cv(ws.cell(2,4)) or 'Cliente')

    last_date = None
    for row in range(7, 200):
        v = ws_mis.cell(row=row, column=1).value
        if isinstance(v, datetime.datetime): last_date = v
        elif v is None: break
    if last_date:
        d['data'] = last_date.strftime('%d/%m/%Y')
    else:
        raw_date = ws.cell(1,4).value
        d['data'] = raw_date.strftime('%d/%m/%Y') if isinstance(raw_date, datetime.datetime) else str(raw_date or '')

    # Kcal totali: L1 = valore normale (min), N3 = valore allenamento 2 (max)
    # Se N3 è barrato non viene usato come max; fallback a M1 (allenamento 1) o solo L1.
    kcal_min = num(ws['L1'])
    kcal_max_n3 = num(ws['N3'])   # allenamento 2 — usato come max se non barrato
    kcal_max_m1 = num(ws['M1'])   # allenamento 1 — fallback
    # Scegli il valore massimo: preferisci N3 se disponibile, altrimenti M1
    kcal_max = kcal_max_n3 if kcal_max_n3 is not None else kcal_max_m1
    if kcal_min and kcal_max and int(kcal_max) != int(kcal_min):
        d['kcal'] = f"{int(kcal_min)}\u2013{int(kcal_max)}"
    elif kcal_min:
        d['kcal'] = str(int(kcal_min))
    elif kcal_max:
        d['kcal'] = str(int(kcal_max))
    else:
        d['kcal'] = '\u2014'

    # Proteine totali (riga 2)
    prot_min = num(ws['L2'])
    prot_max = num(ws['M2'])
    if prot_min and prot_max:
        d['prot_totali'] = f"{int(prot_min)}\u2013{int(prot_max)} g"
    else:
        d['prot_totali'] = ''

    # ── NOTE FOOTER (O1, O2, O3) ─────────────────────────────────────────────
    footer_notes = []
    for row in range(1, 4):
        v = _cv(ws.cell(row=row, column=15))  # colonna O
        if v and not v.startswith('*') or (v and v.startswith('*')):
            # Rimuovi asterisco iniziale se presente
            clean = v.lstrip('*').strip()
            if clean:
                footer_notes.append(clean)
    d['footer_notes'] = footer_notes

    # ── RILEVAMENTO MODALITÀ ALLENAMENTO ─────────────────────────────────────
    has_all1 = False; has_all2 = False
    for row in range(1, 220):
        for col in range(1, 25):
            cell = ws.cell(row=row, column=col)
            if cell.value is None: continue
            fc = cell.font.color if cell.font else None
            if fc and fc.type == 'rgb':
                if fc.rgb == 'FF0070C0': has_all1 = True
                if fc.rgb == 'FF008E40': has_all2 = True
        if has_all1 and has_all2: break
    d['has_all1'] = has_all1
    d['has_all2'] = has_all2

    # ── COLAZIONE ────────────────────────────────────────────────────────────
    col_sec = _sec('COLAZIONE')
    col_header_text = ''
    if col_sec:
        hrow = col_sec[0]
        # kcal: M=norm(col13), N=all1(col14) — colazione non ha all2
        # prot: O=min(col15), P=max(col16)
        col_kcal_str, col_prot_str = _read_section_header(
            ws.cell(hrow, 13), ws.cell(hrow, 14), None,
            ws.cell(hrow, 15), ws.cell(hrow, 16)
        )
        # Leggi header dinamico da J4 (colonna 10)
        col_header_cell = ws.cell(row=4, column=10)
        if col_header_cell and col_header_cell.value:
            col_header_text = str(col_header_cell.value).strip()
        col_kcal_present = bool(col_kcal_str)
    else:
        col_kcal_str = col_prot_str = ''
        col_kcal_present = False

    d['colazione_presente'] = col_kcal_present
    d['colazione_header'] = col_header_text
    d['colazione_kcal'] = col_kcal_str
    d['colazione_prot'] = col_prot_str

    # Incipit colazione: leggi il testo intro da A5 (riga 5, colonna 1)
    col_base = ''
    col_nota_blu = ''
    intro_from_a5 = _cv(ws.cell(row=5, column=1))  # A5
    if intro_from_a5:
        col_base = intro_from_a5
    
    # Se non c'è testo in A5, fallback alle righe sotto l'header (comportamento vecchio)
    if not col_base and col_sec:
        hrow = col_sec[0]
        col_base_parts = []
        for r in range(hrow + 1, hrow + 6):
            for c in range(1, 22):
                cell = ws.cell(row=r, column=c)
                if not _cell_visible(cell): continue
                s = str(cell.value).strip()
                if s.upper().startswith('OPZIONE'): break
                # Nota blu (colore FF0070C0)
                fc = cell.font.color if cell.font else None
                if fc and fc.type == 'rgb' and fc.rgb == 'FF0070C0':
                    col_nota_blu = s; continue
                if s and s not in col_base_parts:
                    col_base_parts.append(s)
            else:
                continue
            break
        col_base = '  '.join(col_base_parts)

    d['colazione_base'] = col_base
    d['colazione_nota_blu'] = col_nota_blu
    d['colazione_latte'] = ''
    d['colazione_intro2'] = ''
    # BUG3 FIX: cap colazione parser at the row where SPUNTINO MATTINA begins
    # Se SPUNTINO MATTINA è barrato/assente, usa la riga del PRANZO come stop
    # (evita che il parser legga i carboidrati del pranzo come opzioni colazione)
    _pranzo_row = _sec('PRANZO')[0] if _sec('PRANZO') else 999
    _sm_row = _sec('SPUNTINO MATTINA')[0] if _sec('SPUNTINO MATTINA') else None
    if _sm_row and _sm_row < _pranzo_row:
        _col_stop = _sm_row
    else:
        _col_stop = _pranzo_row if _pranzo_row < 999 else 39
    d['colazione_opzioni'] = _read_colazione_options(ws, _col_stop)
    # ── SPUNTINO MATTINA ─────────────────────────────────────────────────────
    sm_sec = _sec('SPUNTINO MATTINA')
    sm_title_text = ''
    sm_intro_text = ''
    if sm_sec:
        hrow = sm_sec[0]
        # kcal: L=norm(col12), M=all1(col13) — spuntino non ha all2
        # prot: O=min(col15), P=max(col16)
        sm_kcal_str, sm_prot_str = _read_section_header(
            ws.cell(hrow, 12), ws.cell(hrow, 13), None,
            ws.cell(hrow, 15), ws.cell(hrow, 16)
        )
        # Leggi il titolo dello spuntino dalla colonna H (8)
        sm_title_cell = ws.cell(row=hrow, column=8)
        if sm_title_cell and sm_title_cell.value:
            sm_title_text = str(sm_title_cell.value).strip()
        # Leggi il testo intro da A40 (riga hrow+1, colonna 1)
        sm_intro_cell = ws.cell(row=hrow + 1, column=1)
        if sm_intro_cell and sm_intro_cell.value:
            sm_intro_text = str(sm_intro_cell.value).strip()
        # Base e bullets
        sm_base = ''
        for r in range(hrow + 1, hrow + 4):
            v = _cv(ws.cell(row=r, column=1))
            if v and ws.cell(row=r, column=2).value != '\u00b0':
                sm_base = v; break
        sm_bullet_start = hrow + 1
        for r in range(hrow + 1, hrow + 10):
            if ws.cell(row=r, column=2).value == '\u00b0':
                sm_bullet_start = r; break
        sm_bullet_end = sm_bullet_start
        for r in range(sm_bullet_start, sm_bullet_start + 40):
            if ws.cell(row=r, column=2).value == '\u00b0' or ws.cell(row=r, column=3).value in ('a)','b)','c)','d)','e)','f)') or ws.cell(row=r, column=4).value in ('a)','b)','c)','d)','e)','f)'):
                sm_bullet_end = r
            elif ws.cell(row=r, column=2).value is None and all(
                ws.cell(row=r, column=c).value is None for c in range(1, 6)
            ):
                break
    else:
        sm_kcal_str = sm_prot_str = ''
        sm_base = ''; sm_bullet_start = 42; sm_bullet_end = 57

    d['spuntino_mattina_presente'] = bool(sm_kcal_str)
    d['spuntino_mattina_title'] = sm_title_text
    d['spuntino_mattina_intro'] = sm_intro_text
    d['spuntino_mattina_kcal'] = sm_kcal_str
    d['spuntino_mattina_prot'] = sm_prot_str
    d['spuntino_mattina_base'] = sm_base
    d['spuntino_mattina_opzioni'] = _read_spuntino_options(ws, sm_bullet_start, sm_bullet_end)

    # ── PRANZO ───────────────────────────────────────────────────────────────
    pr_sec = _sec('PRANZO')
    if pr_sec:
        hrow = pr_sec[0]
        # kcal: L=norm(col12), M=all1(col13), N=all2(col14)
        # prot: O=min(col15), P=max(col16)
        pranzo_kcal_str, pranzo_prot_str = _read_section_header(
            ws.cell(hrow, 12), ws.cell(hrow, 13), ws.cell(hrow, 14),
            ws.cell(hrow, 15), ws.cell(hrow, 16)
        )
        pranzo_presente = bool(pranzo_kcal_str)
        
        # Leggi verdure e condimento da celle specifiche (A59, A61)
        pranzo_verdure = _cv(ws.cell(row=hrow + 1, column=1))
        pranzo_condimento = _cv(ws.cell(row=hrow + 3, column=1))
        if not pranzo_verdure:
            pranzo_verdure = _cv(ws.cell(row=59, column=1))
        if not pranzo_condimento:
            pranzo_condimento = _cv(ws.cell(row=61, column=1))

        # Leggi testo dinamico da A62 per istruzioni PRANZO
        pranzo_istruzione = _cv(ws.cell(row=hrow + 4, column=1))
        if not pranzo_istruzione:
            pranzo_istruzione = _cv(ws.cell(row=62, column=1))
        if not pranzo_istruzione:
            pranzo_istruzione = "Abbina poi un'opzione di carboidrati ad un'opzione proteica fra quelle proposte di seguito:"

        # Leggi testo dinamico da A78 per header mix PRANZO
        pranzo_mix_header = _cv(ws.cell(row=78, column=1))
        if not pranzo_mix_header:
            pranzo_mix_header = "Mix Proteici"

        # Carbo start: prima riga con B='°' dopo header
        pr_carbo_start = hrow + 6
        for r in range(hrow + 1, hrow + 12):
            if ws.cell(row=r, column=2).value == '\u00b0':
                pr_carbo_start = r; break
        # Mix start: riga con 'mix' in col A
        pr_mix_start = pr_carbo_start + 14
        for r in range(pr_carbo_start, pr_carbo_start + 40):
            v = str(ws.cell(row=r, column=1).value or '').lower()
            if 'mix' in v:
                pr_mix_start = r; break
        pr_carbo_end = pr_mix_start - 1
        _GIORNI_KW = ['LUNEDI','LUNEDÌ','MARTEDI','MARTEDÌ','MERCOLEDI','MERCOLEDÌ',
                      'GIOVEDI','GIOVEDÌ','VENERDI','VENERDÌ','SABATO','DOMENICA']
        def _find_esempi_start(mix_start):
            for r in range(mix_start, mix_start + 35):
                for c in range(1, 25):
                    v = str(ws.cell(row=r, column=c).value or '').strip().upper()
                    if any(v == g or v.startswith(g[:5]) for g in _GIORNI_KW):
                        return r
            return mix_start + 25
        pr_esempi_start = _find_esempi_start(pr_mix_start)
        pr_mix_end = pr_esempi_start - 1
        sp_pm_row = _sec('SPUNTINO POMERIGGIO')[0] if _sec('SPUNTINO POMERIGGIO') else pr_esempi_start + 15
        pr_esempi_end = sp_pm_row - 1
    else:
        pranzo_kcal_str = pranzo_prot_str = ''
        pranzo_presente = False
        pranzo_verdure = pranzo_condimento = ''
        pranzo_istruzione = "Abbina poi un'opzione di carboidrati ad un'opzione proteica fra quelle proposte di seguito:"
        pranzo_mix_header = "Mix Proteici"
        pr_carbo_start = 65; pr_carbo_end = 78; pr_mix_start = 79; pr_mix_end = 101
        pr_esempi_start = 102; pr_esempi_end = 113

    # Header PRANZO letto da I58
    pranzo_header_cell = ws.cell(row=pr_sec[0] if pr_sec else 58, column=9)
    d['pranzo_header'] = str(pranzo_header_cell.value).strip() if pranzo_header_cell.value else 'PRANZO'
    d['pranzo_presente'] = pranzo_presente
    d['pranzo_kcal'] = pranzo_kcal_str
    d['pranzo_prot'] = pranzo_prot_str
    d['pranzo_verdure']    = pranzo_verdure
    d['pranzo_condimento'] = pranzo_condimento
    d['pranzo_istruzione'] = pranzo_istruzione  # Testo dinamico da A62
    d['pranzo_mix_header'] = pranzo_mix_header  # Header dinamico da A78
    d['pranzo_carbo'], d['pranzo_prot_cols'], d['pranzo_mix'] = _read_pasto_options(
        ws, pr_carbo_start, pr_carbo_end, pr_mix_start, pr_mix_end)
    d['pranzo_esempi'] = _read_esempi(ws, pr_esempi_start, pr_esempi_end)
    d['pranzo_note'] = ''

    # ── SPUNTINO POMERIGGIO ───────────────────────────────────────────────────
    spm_sec = _sec('SPUNTINO POMERIGGIO')
    spm_is_strikethrough = False  # Flag per verificare se è barrato
    spm_title_text = ''  # Testo dell'intestazione
    spm_intro_text = ''  # Testo intro da A114
    if spm_sec:
        hrow = spm_sec[0]
        
        # Verifica se la riga è barrata (strikethrough)
        header_cell = ws.cell(row=hrow, column=1)
        if header_cell.font and header_cell.font.strike:
            spm_is_strikethrough = True
        
        # Leggi il titolo dello spuntino dalla colonna H (8)
        spm_title_cell = ws.cell(row=hrow, column=8)
        if spm_title_cell and spm_title_cell.value and not spm_is_strikethrough:
            spm_title_text = str(spm_title_cell.value).strip()
        
        # Leggi il testo intro da A114 (riga 114, colonna 1)
        spm_intro_cell = ws.cell(row=114, column=1)
        if spm_intro_cell and spm_intro_cell.value and not spm_is_strikethrough:
            spm_intro_text = str(spm_intro_cell.value).strip()
        
        # kcal: L=norm(col12), M=all1(col13) — spuntino pomeriggio non ha all2
        # prot: O=min(col15), P=max(col16)
        spm_kcal_str, spm_prot_str = _read_section_header(
            ws.cell(hrow, 12), ws.cell(hrow, 13), None,
            ws.cell(hrow, 15), ws.cell(hrow, 16)
        )
        spm_base = ''
        for r in range(hrow + 1, hrow + 4):
            v = _cv(ws.cell(row=r, column=1))
            if v and ws.cell(row=r, column=2).value != '\u00b0':
                spm_base = v; break
        spm_bullet_start = hrow + 1
        for r in range(hrow + 1, hrow + 8):
            if ws.cell(row=r, column=2).value == '\u00b0':
                spm_bullet_start = r; break
        spm_bullet_end = spm_bullet_start
        cena_row = _sec('CENA')[0] if _sec('CENA') else spm_bullet_start + 25
        for r in range(spm_bullet_start, cena_row):
            b = ws.cell(row=r, column=2).value
            if b == '\u00b0' or ws.cell(row=r, column=3).value in ('a)','b)','c)','d)','e)','f)') or ws.cell(row=r, column=4).value in ('a)','b)','c)','d)','e)','f)'):
                spm_bullet_end = r
    else:
        spm_kcal_str = spm_prot_str = ''
        spm_base = ''; spm_bullet_start = 117; spm_bullet_end = 133

    # Se barrato, non mostrare
    d['spuntino_pomeriggio_presente'] = bool(spm_kcal_str) and not spm_is_strikethrough
    d['spuntino_pomeriggio_title'] = spm_title_text
    d['spuntino_pomeriggio_intro'] = spm_intro_text
    d['spuntino_pomeriggio_kcal'] = spm_kcal_str
    d['spuntino_pomeriggio_prot'] = spm_prot_str
    d['spuntino_pomeriggio_base'] = spm_base
    d['spuntino_pomeriggio_opzioni'] = _read_spuntino_options(ws, spm_bullet_start, spm_bullet_end)

    # ── CENA ─────────────────────────────────────────────────────────────────
    ce_sec = _sec('CENA')
    if ce_sec:
        hrow = ce_sec[0]
        # kcal: L=norm(col12), M=all1(col13), N=all2(col14)
        # prot: O=min(col15), P=max(col16)
        cena_kcal_str, cena_prot_str = _read_section_header(
            ws.cell(hrow, 12), ws.cell(hrow, 13), ws.cell(hrow, 14),
            ws.cell(hrow, 15), ws.cell(hrow, 16)
        )
        cena_presente = bool(cena_kcal_str)
        
        # Leggi verdure e condimento da celle specifiche (A134, A136)
        cena_verdure = _cv(ws.cell(row=134, column=1))  # A134
        cena_condimento = _cv(ws.cell(row=136, column=1))  # A136
        
        # Leggi testo dinamico da A137 per istruzioni CENA
        cena_istruzione = _cv(ws.cell(row=137, column=1))  # A137
        if not cena_istruzione:
            cena_istruzione = "Abbina un'opzione di carboidrati ad un'opzione proteica fra quelle proposte di seguito:"
        
        # Leggi testo dinamico da A153 per header mix CENA
        cena_mix_header = _cv(ws.cell(row=153, column=1))  # A153
        if not cena_mix_header:
            cena_mix_header = "Mix Proteici"
        
        ce_carbo_start = hrow + 6
        for r in range(hrow + 1, hrow + 12):
            if ws.cell(row=r, column=2).value == '\u00b0':
                ce_carbo_start = r; break
        ce_mix_start = ce_carbo_start + 14
        for r in range(ce_carbo_start, ce_carbo_start + 40):
            v = str(ws.cell(row=r, column=1).value or '').lower()
            if 'mix' in v:
                ce_mix_start = r; break
        ce_carbo_end = ce_mix_start - 1
        ce_esempi_start = _find_esempi_start(ce_mix_start)
        ce_mix_end = ce_esempi_start - 1
        # Find pasto fuori / integrazione
        pf_row = None
        for r in range(ce_mix_end, ce_mix_end + 40):
            v = str(ws.cell(row=r, column=1).value or '').upper()
            if 'PASTO FUORI' in v or 'INTEGRAZIONE' in v:
                pf_row = r; break
        ce_esempi_end = (pf_row - 1) if pf_row else ce_mix_end + 15
    else:
        cena_kcal_str = cena_prot_str = ''
        cena_presente = False
        cena_verdure = cena_condimento = ''
        cena_istruzione = "Abbina un'opzione di carboidrati ad un'opzione proteica fra quelle proposte di seguito:"
        cena_mix_header = "Mix Proteici"
        ce_carbo_start = 140; ce_carbo_end = 153; ce_mix_start = 154; ce_mix_end = 175
        ce_esempi_start = 176; ce_esempi_end = 187

    # Header CENA letto da J133
    cena_header_cell = ws.cell(row=ce_sec[0] if ce_sec else 133, column=10)
    d['cena_header'] = str(cena_header_cell.value).strip() if cena_header_cell.value else 'CENA'
    d['cena_presente'] = cena_presente
    d['cena_kcal'] = cena_kcal_str
    d['cena_prot'] = cena_prot_str
    d['cena_verdure']    = cena_verdure
    d['cena_condimento'] = cena_condimento
    d['cena_istruzione'] = cena_istruzione  # Testo dinamico da A137
    d['cena_mix_header'] = cena_mix_header  # Header dinamico da A153
    d['cena_carbo'], d['cena_prot_cols'], d['cena_mix'] = _read_pasto_options(
        ws, ce_carbo_start, ce_carbo_end, ce_mix_start, ce_mix_end)
    d['cena_esempi'] = _read_esempi(ws, ce_esempi_start, ce_esempi_end)
    d['cena_note'] = ''

    # ── PASTO FUORI (keyword-based parser) ───────────────────────────────────
    # Cerca la riga header 'PASTO FUORI', poi legge le righe sottostanti
    # per keyword in colonna A: VERDURE / CARBO / CARBOIDRATI / PROTEINE
    # Il testo effettivo è sempre in colonna D (col 4).
    pf_header_row = None
    for row in range(1, 220):
        v = str(ws.cell(row=row, column=1).value or '').strip().upper()
        if 'PASTO FUORI' in v:
            pf_header_row = row; break

    pf_raw = {}   # label → text
    pf_locali_rows = []
    if pf_header_row:
        for r in range(pf_header_row + 1, pf_header_row + 15):
            lbl = str(ws.cell(row=r, column=1).value or '').strip().upper()
            txt = cv(ws.cell(row=r, column=4))
            if not lbl and not txt:
                continue
            if lbl in ('VERDURE', 'CARBO', 'CARBOIDRATI', 'PROTEINE'):
                pf_raw[lbl] = txt
            elif lbl == 'INTEGRAZIONE' or lbl.startswith('INTEG'):
                break

    # Mappa label → contenuto testuale con rilevamento automatico
    def _is_verdure_text(t):
        return 'verdure' in t.lower() and ('insalata' in t.lower() or 'grigliata' in t.lower() or 'vapore' in t.lower())
    def _is_carbo_text(t):
        return 'carboidrati' in t.lower() or 'grissini' in t.lower() or 'pane' in t.lower()
    def _is_prot_text(t):
        return ('proteic' in t.lower() or 'legumi' in t.lower() or 'pesce' in t.lower()
                or 'carne' in t.lower() or 'tofu' in t.lower() or 'falafel' in t.lower())

    # Raccoglie tutti i testi trovati e li smista per contenuto
    all_pf_texts = list(pf_raw.values())
    mapped_verd  = next((t for t in all_pf_texts if _is_verdure_text(t)), pf_raw.get('VERDURE', ''))
    mapped_carbo = next((t for t in all_pf_texts if _is_carbo_text(t)),  pf_raw.get('CARBO', pf_raw.get('CARBOIDRATI', '')))
    mapped_prot  = next((t for t in all_pf_texts if _is_prot_text(t)),   pf_raw.get('PROTEINE', ''))

    d['pasto_fuori_presente'] = any([mapped_verd, mapped_carbo, mapped_prot])
    d['pasto_fuori_rows'] = []
    if mapped_verd:
        d['pasto_fuori_rows'].append(('VERDURE',     mapped_verd,  GREEN_DARK))
    if mapped_carbo:
        d['pasto_fuori_rows'].append(('CARBOIDRATI', mapped_carbo, ORANGE))
    if mapped_prot:
        d['pasto_fuori_rows'].append(('PROTEINE',    mapped_prot,  PURPLE))

    # Scan for restaurant/local names after pasto fuori section
    locali = []
    if pf_header_row:
        for r in range(pf_header_row + 1, pf_header_row + 15):
            lbl = str(ws.cell(row=r, column=1).value or '').strip().upper()
            if lbl in ('INTEGRAZIONE',) or lbl.startswith('INTEG'):
                break
            for col in range(1, 10):
                v = cv(ws.cell(row=r, column=col))
                if v and len(v) > 4 and v not in (mapped_verd, mapped_carbo, mapped_prot):
                    words = v.split()
                    if len(words) >= 2 and all(w[0].isupper() for w in words if w):
                        locali.append(v)
    d['pasto_fuori_locali'] = locali

    # ── INTEGRAZIONE (rows 195–199, si ferma prima delle sezioni extra) ────────
    integ = []
    for r in range(195, 200):
        line_parts = []
        for col in range(1, 12):
            v = cv(ws.cell(row=r, column=col))
            if v and v not in ('INTEGRAZIONE',):
                line_parts.append(v)
        line = '  '.join(line_parts).strip()
        if line and line != 'INTEGRAZIONE':
            integ.append(line)
    d['integrazione_presente'] = len(integ) > 0
    d['integrazione'] = integ

    # ── SEZIONI EXTRA (max 3, dalla riga 200 in poi) ──────────────────────────
    def _read_rich_cell(cell):
        """
        Legge il contenuto di una cella preservando:
        - Grassetto, corsivo, sottolineato a livello di run
        - A capo espliciti (\n) presenti nel valore della cella
        Restituisce una lista di segmenti: [{'text': str, 'bold': bool, 'italic': bool, 'underline': bool}]
        oppure None se la cella è vuota/barrata.
        """
        if cell.font and cell.font.strike:
            return None
        val = cell.value
        if val is None:
            return None

        # openpyxl: se la cella ha formattazione rich-text, cell._value è un oggetto CellRichText
        # oppure i run si trovano in cell.value se è già stato parsato
        try:
            from openpyxl.cell.rich_text import CellRichText, TextBlock
        except ImportError:
            CellRichText = None
            TextBlock = None

        segments = []

        if CellRichText is not None and isinstance(val, CellRichText):
            # Rich text: ogni TextBlock è un run con formattazione propria
            for block in val:
                if isinstance(block, TextBlock):
                    text = str(block.text) if block.text else ''
                    font = block.font
                    bold      = bool(font and font.b)
                    italic    = bool(font and font.i)
                    underline = bool(font and font.u and font.u not in (None, 'none', False))
                    if text:
                        segments.append({'text': text, 'bold': bold, 'italic': italic, 'underline': underline})
                else:
                    # stringa pura senza formattazione
                    text = str(block) if block else ''
                    if text:
                        segments.append({'text': text, 'bold': False, 'italic': False, 'underline': False})
        else:
            # Cella plain text: usa la formattazione della cella intera
            text = str(val)
            font = cell.font
            bold      = bool(font and font.bold)
            italic    = bool(font and font.italic)
            underline = bool(font and font.underline and font.underline not in (None, 'none', False))
            segments.append({'text': text, 'bold': bold, 'italic': italic, 'underline': underline})

        if not segments:
            return None
        # Sanifica il testo: rimuovi tab (che ReportLab non gestisce)
        # -	 diventa '- ', 	 semplice diventa spazio
        def _clean(t):
            t = t.replace('-	', '- ')
            t = t.replace('	', ' ')
            return t
        for seg in segments:
            seg['text'] = _clean(seg['text'])
        segments = [s for s in segments if s['text']]
        if not segments:
            return None
        return segments

    extra_sections = []
    r = 200
    while r < 230 and len(extra_sections) < 3:
        titolo_cell = ws.cell(row=r, column=1)
        titolo = str(titolo_cell.value or '').strip()
        if not titolo:
            r += 1; continue
        
        # Verifica se la riga è barrata (strikethrough)
        is_strikethrough = titolo_cell.font and titolo_cell.font.strike
        if is_strikethrough:
            r += 1; continue
        
        # Raccoglie tutte le righe di testo consecutive sotto il titolo
        # Ogni elemento di 'righe' è ora una lista di segmenti rich-text
        righe = []
        r2 = r + 1
        while r2 <= r + 20:
            cell2 = ws.cell(row=r2, column=1)
            v = str(cell2.value or '').strip()
            if not v:
                break
            # Se è un altro titolo (tutto maiuscolo breve), fermati
            if v.upper() == v and len(v) < 40 and r2 > r + 1:
                break
            segs = _read_rich_cell(cell2)
            if segs:
                righe.append(segs)
            r2 += 1
        if titolo and righe:
            extra_sections.append({'titolo': titolo, 'righe': righe})
        r = r2 + 1

    d['extra_sections'] = extra_sections

    return d


def _read_colazione_options(ws, stop_row=39):
    """
    Parse colazione options from rows 7 up to (but not including) stop_row.
    stop_row defaults to 39 (the SPUNTINO MATTINA header row for most files).
    BUG3 FIX: the caller passes the actual SPUNTINO MATTINA row so the parser
    never reads bullet rows that belong to a later section.

    Left column (B) and right column (M) are always INDEPENDENT options.
    Each OPZIONE header starts a new option; bullets below belong to it.

    OPZIONE 1 special structure:
      - rows 8-9: carbo-choice rows (Pane/Gallette/Piadina etc.)
      - row 10: "Con una delle seguenti opzioni:" sub-header
      - rows 11+: protein bullets

    OPZIONE 2/4 (left side): row immediately after header has B=number/text, C=name → first item
    OPZIONE 3/5 (right side): row immediately after header has M=grams, O=name → first item
    """
    options = []
    left_opt  = None
    right_opt = None

    for row in range(7, stop_row):
        b = cv(ws.cell(row=row, column=2))
        m = cv(ws.cell(row=row, column=13))

        # ── New OPZIONE header LEFT ───────────────────────────────────────────
        if b.upper().startswith('OPZIONE'):
            if left_opt:
                # Finalizza single_header_parts prima di appendere
                if 'single_header_parts' in left_opt:
                    _parts = left_opt.pop('single_header_parts', [])
                    _q = left_opt.pop('single_header_q', '')
                    if _q: _parts.append(_q)
                    if _parts: left_opt['header_item'] = '  '.join(_parts)
                options.append(left_opt)
            b_cell = ws.cell(row=row, column=2)
            if b_cell.font and b_cell.font.strike:
                left_opt = None  # opzione barrata → ignorala
            else:
                left_opt = {'titolo': b.replace(':', '').strip(), 'items': [], 'sub_header': ''}

        # ── New OPZIONE header RIGHT ──────────────────────────────────────────
        if m.upper().startswith('OPZIONE'):
            if right_opt: options.append(right_opt)
            m_cell = ws.cell(row=row, column=13)
            if m_cell.font and m_cell.font.strike:
                right_opt = None  # opzione barrata → ignorala
            else:
                right_opt = {'titolo': m.replace(':', '').strip(), 'items': [], 'sub_header': ''}

        # ── Non-bullet rows on LEFT (B is not '°' and not an OPZIONE header) ─
        b_raw = ws.cell(row=row, column=2).value  # raw value before cv()
        b_is_non_bullet = (b_raw is None or (b_raw != '°' and not str(b_raw).upper().startswith('OPZIONE')))
        if left_opt is not None and b_is_non_bullet:
            # Grammi possono essere in C2 (b_raw numerico) oppure C3
            b_num = num(ws.cell(row=row, column=2))
            c3    = num(ws.cell(row=row, column=3))
            g7    = num(ws.cell(row=row, column=7))
            k11   = num(ws.cell(row=row, column=11))

            if b_num is not None or c3 is not None or g7 is not None or k11 is not None:
                # Numeric row — carbo-choice (Op.1) or opening quantity (Op.2/4)
                opt_num_match = int(__import__('re').search(r'(\d+)', left_opt['titolo']).group(1)) \
                    if __import__('re').search(r'(\d+)', left_opt['titolo']) else 0

                if opt_num_match == 1:
                    # OPZIONE 1: tutte le righe (R8, R9, ...) vengono concatenate in
                    # UN'UNICA stringa bold, nell'ordine esatto specificato.
                    # La stringa viene accumulata in left_opt['single_header'] e
                    # convertita in header_item solo al termine del loop.
                    #
                    # Ordine per ogni riga:
                    #   B(col2)/D(col4) + E(col5)          → grammi + nome A
                    #   F(col6) se 'o'                     → separatore
                    #   G(col7)/H(col8) + I(col9)          → grammi + nome B  (se F='o')
                    #   K(col11)/L(col12) + M(col13)       → grammi+nome C oppure kcal tot
                    #   N(col14)                           → separatore se presente
                    #   (riga successiva contribuisce con i suoi gruppi)
                    # Alla fine di tutte le righe: Q8(col17) dell'ultima riga con valore

                    def _food_str_op1(g_base, g_blu, name):
                        gstr = _fmt_grams(g_base, g_blu, None)
                        return f"{gstr} {name}".strip() if gstr else name

                    if 'single_header_parts' not in left_opt:
                        left_opt['single_header_parts'] = []
                        left_opt['single_header_q'] = ''

                    parts = left_opt['single_header_parts']

                    # Gruppo A: B(col2)=norm, D(col4)=all, E(col5)=nome
                    g_a  = num(ws.cell(row=row, column=2))
                    g_ab = num(ws.cell(row=row, column=4))
                    n_a  = cv(ws.cell(row=row, column=5))
                    if n_a:
                        if parts:
                            parts.append('o')
                        parts.append(_food_str_op1(g_a, g_ab, n_a))

                    # F(col6): separatore tra gruppo A e B nella stessa riga
                    f6 = str(ws.cell(row=row, column=6).value or '').strip().lower()
                    g7 = str(ws.cell(row=row, column=7).value or '').strip().lower()

                    # Gruppo B: G(col7)/H(col8) + I(col9)  — se F8='o'
                    if f6 == 'o':
                        g_b  = num(ws.cell(row=row, column=7))
                        g_bb = num(ws.cell(row=row, column=8))
                        n_b  = cv(ws.cell(row=row, column=9))
                        if n_b:
                            parts.append('o')
                            parts.append(_food_str_op1(g_b, g_bb, n_b))
                        # K(col11)/L(col12) + I(col9) di nuovo per kcal, M(col13)='tot'
                        c13_raw = ws.cell(row=row, column=13).value
                        c13_str = str(c13_raw).strip() if c13_raw else ''
                        if c13_str.lower() in ('tot', 'totali', 'kcal'):
                            kc1 = num(ws.cell(row=row, column=11))
                            kc2 = num(ws.cell(row=row, column=12))
                            if kc1:
                                kstr = f"{int(kc1)} kcal"
                                if kc2 and kc2 != kc1: kstr += f" / {int(kc2)} kcal all."
                                parts.append(kstr)
                        elif c13_str and not c13_str.upper().startswith('OPZIONE'):
                            # Third food item (e.g. Piadina) with connector in C10
                            c10_str = str(ws.cell(row=row, column=10).value or '').strip().lower()
                            if c10_str in ('o', 'e', '+'):
                                g_c  = num(ws.cell(row=row, column=11))
                                g_cb = num(ws.cell(row=row, column=12))
                                parts.append('o')
                                parts.append(_food_str_op1(g_c, g_cb, c13_str))

                    # Gruppo per R9: G9='o' → H(col8)/I(col9) + J(col10), poi K/L/M
                    elif g7 == 'o':
                        g_b  = num(ws.cell(row=row, column=8))
                        g_bb = num(ws.cell(row=row, column=9))
                        n_b  = cv(ws.cell(row=row, column=10))
                        if n_b:
                            parts.append('o')
                            parts.append(_food_str_op1(g_b, g_bb, n_b))
                        # K(col11)/L(col12) + M(col13)=nome terzo alimento
                        c13_raw = ws.cell(row=row, column=13).value
                        c13_str = str(c13_raw).strip() if c13_raw else ''
                        if c13_str and c13_str.lower() not in ('tot','totali','kcal') and not c13_str.upper().startswith('OPZIONE'):
                            g_c  = num(ws.cell(row=row, column=11))
                            g_cb = num(ws.cell(row=row, column=12))
                            parts.append('o')
                            parts.append(_food_str_op1(g_c, g_cb, c13_str))

                    # N(col14): separatore tra blocco R8 e blocco R9
                    n14 = cv(ws.cell(row=row, column=14))
                    if n14 and n14.lower() not in ('o','e','+'):
                        parts.append(n14)

                    # Q(col17): annotazione finale (prendi l'ultima non vuota)
                    q17 = cv(ws.cell(row=row, column=17))
                    if q17:
                        left_opt['single_header_q'] = q17
                else:
                    # OPZIONE 2/4: opening line with quantity + name
                    # Case A: B='1', C='BUDINO PROTEICO' (text label)
                    # Case B: B='', C=300(grams), D=grams_blu, E='Latte parzi...' (name)
                    name_c = cv(ws.cell(row=row, column=3))
                    name_e = cv(ws.cell(row=row, column=5))
                    grams_c = num(ws.cell(row=row, column=3))
                    grams_d = num(ws.cell(row=row, column=4))

                    if name_c and not name_c.startswith('*'):
                        try:
                            float(name_c)
                            # C is numeric → grams + name in E, annotation in F (col 6)
                            # Se E è barrata/vuota, cerca nelle righe successive la prima E non barrata
                            actual_name_e = name_e
                            actual_annot_f6 = cv(ws.cell(row=row, column=6))
                            if not actual_name_e:
                                for next_r in range(row + 1, row + 5):
                                    ne = cv(ws.cell(row=next_r, column=5))
                                    if ne and not ne.startswith('*'):
                                        actual_name_e = ne
                                        actual_annot_f6 = cv(ws.cell(row=next_r, column=6))
                                        break
                            if actual_name_e and not actual_name_e.startswith('*'):
                                gstr = _fmt_grams(grams_c, grams_d, None)
                                suffix_f6 = f'  {actual_annot_f6}' if actual_annot_f6 and actual_annot_f6.lower() not in ('o','e','+') else ''
                                left_opt['header_item'] = f"{gstr} {actual_name_e}{suffix_f6}"
                        except ValueError:
                            # C is text label (e.g. "BUDINO PROTEICO")
                            # Ordine: C (nome) → I kcal / J kcal all. → F → K
                            b_str = str(b_raw).strip() if b_raw is not None else ''
                            prefix = f"{b_str} " if b_str and b_str not in ('°',) else ''
                            label = (prefix + name_c).strip()
                            # I(col9) / J(col10): kcal normale / allenamento
                            kc1 = num(ws.cell(row=row, column=9))
                            kc2 = num(ws.cell(row=row, column=10))
                            if kc1:
                                kstr = f"{int(kc1)} kcal"
                                if kc2 and kc2 != kc1: kstr += f" / {int(kc2)} kcal all."
                                label += f"  {kstr}"
                            # F(col6): testo aggiuntivo
                            annot_f6 = cv(ws.cell(row=row, column=6))
                            if annot_f6 and annot_f6.lower() not in ('o','e','+'):
                                label += f'  {annot_f6}'
                            # K(col11): testo aggiuntivo
                            annot_k11 = cv(ws.cell(row=row, column=11))
                            if annot_k11 and annot_k11.lower() not in ('o','e','+'):
                                label += f'  {annot_k11}'
                            left_opt['header_item'] = label
                    elif name_e and not name_e.startswith('*') and grams_c:
                        gstr = _fmt_grams(grams_c, grams_d, None)
                        left_opt['header_item'] = f"{gstr} {name_e}"
            else:
                # No grams on this row — check if it's a text label header (e.g. B=1, C='BUDINO PROTEICO')
                name_c = cv(ws.cell(row=row, column=3))
                b_str = str(b_raw).strip() if b_raw is not None else ''
                if name_c and not name_c.startswith('*'):
                    try:
                        float(name_c)  # if C is numeric, it's not a label
                    except ValueError:
                        # C is a text label — leggi anche I/J (kcal) poi F poi K
                        prefix = f"{b_str} " if b_str and b_str not in ('°',) else ''
                        label = (prefix + name_c).strip()
                        kc1 = num(ws.cell(row=row, column=9))
                        kc2 = num(ws.cell(row=row, column=10))
                        if kc1:
                            kstr = f"{int(kc1)} kcal"
                            if kc2 and kc2 != kc1: kstr += f" / {int(kc2)} kcal all."
                            label += f"  {kstr}"
                        annot_f6 = cv(ws.cell(row=row, column=6))
                        if annot_f6 and annot_f6.lower() not in ('o','e','+'):
                            label += f'  {annot_f6}'
                        annot_k11 = cv(ws.cell(row=row, column=11))
                        if annot_k11 and annot_k11.lower() not in ('o','e','+'):
                            label += f'  {annot_k11}'
                        left_opt['header_item'] = label
                elif not name_c and not b.startswith('*'):
                    # Pure text in B (like "Con una delle seguenti opzioni:")
                    left_opt['sub_header'] = b

        # ── Non-bullet rows on RIGHT (M is not '°' and not OPZIONE header) ───
        if right_opt is not None and m and m != '°' and not m.upper().startswith('OPZIONE'):
            # Check for opening quantity row: M=grams_base, N=grams_blu, O=name, Q=annotation
            m_g1 = num(ws.cell(row=row, column=13))
            m_g2 = num(ws.cell(row=row, column=14))
            n_o  = cv(ws.cell(row=row, column=15))
            n_p  = cv(ws.cell(row=row, column=16))  # possible continuation of name
            if m_g1 is not None and (n_o or n_p):
                full_name = ' '.join(x for x in [n_o, n_p] if x and not x.startswith('*'))
                if full_name:
                    gstr = _fmt_grams(m_g1, m_g2, None)
                    annot_q17 = cv(ws.cell(row=row, column=17))
                    suffix_q17 = f'  {annot_q17}' if annot_q17 and annot_q17.lower() not in ('o','e','+') else ''
                    right_opt['header_item'] = f"{gstr} {full_name}{suffix_q17}"

        # ── Bullet on LEFT (col B = '°') ──────────────────────────────────────
        if b == '°' and left_opt is not None:
            g1    = num(ws.cell(row=row, column=3))
            g1b   = num(ws.cell(row=row, column=4))
            name1 = cv(ws.cell(row=row, column=5))
            c3_raw = ws.cell(row=row, column=3).value
            c3_empty = g1 is None and (c3_raw is None or str(c3_raw).strip() in ('#N/A','#REF!','#NUM!',''))

            # ── Check for connector (' e ') in col 7 or 9 (combo rows R21-26) ──
            # Pattern A (R25-26): C7=' e ', C8=g2_base, C9=g2_blu, C10=name2
            # Pattern B (R21-24): C9=' e ', C10=g2_base, C11=g2_blu, C12=name2
            #   R24 also has 3rd element: C14=g3_base, C15=g3_blu, C16=name3
            connector_found = False
            if not c3_empty and name1:
                conn7 = str(ws.cell(row=row, column=7).value or '').strip().lower()
                conn9 = str(ws.cell(row=row, column=9).value or '').strip().lower()

                if conn7 in ('e', '+', 'o'):
                    # Pattern A
                    g2_base = num(ws.cell(row=row, column=8))
                    g2_blu  = num(ws.cell(row=row, column=9))
                    name2   = cv(ws.cell(row=row, column=10)).split('*')[0].strip()
                    if name2:
                        # BUG FIX: grammi adiacenti al proprio alimento
                        # Format: "Xg NomeA  +  Yg NomeB"
                        segs1 = _fmt_grams_segments(g1, g1b, None)
                        segs2 = _fmt_grams_segments(g2_base, g2_blu, None)
                        # Build interleaved segs: [segs1, " nome1  +  ", segs2, " nome2"]
                        all_segs = segs1 + [('  ' + name1 + '  +  ', 'normal')] + segs2
                        left_opt['items'].append({'name': name2, 'segs': all_segs})
                        connector_found = True

                elif conn9 in ('e', '+', 'o'):
                    # Pattern B
                    g2_base = num(ws.cell(row=row, column=10))
                    g2_blu  = num(ws.cell(row=row, column=11))
                    name2   = cv(ws.cell(row=row, column=12)).split('*')[0].strip()
                    if name2:
                        # BUG FIX: grammi adiacenti al proprio alimento
                        segs1 = _fmt_grams_segments(g1, g1b, None)
                        segs2 = _fmt_grams_segments(g2_base, g2_blu, None)
                        # Build interleaved segs: [segs1, " nome1  +  ", segs2, " nome2"]
                        all_segs = segs1 + [('  ' + name1 + '  +  ', 'normal')] + segs2
                        full_name = name2
                        # Third element? R24: C14=g3_base, C15=g3_blu, C16=name3
                        name3 = cv(ws.cell(row=row, column=16)).split('*')[0].strip()
                        if name3:
                            g3_base = num(ws.cell(row=row, column=14))
                            g3_blu  = num(ws.cell(row=row, column=15))
                            segs3   = _fmt_grams_segments(g3_base, g3_blu, None)
                            if segs3:
                                all_segs += [('  ' + name2 + '  +  ', 'normal')] + segs3
                                full_name = name3
                            else:
                                full_name = name2 + '  +  ' + name3
                        left_opt['items'].append({'name': full_name, 'segs': all_segs})
                        connector_found = True

            if connector_found:
                pass  # already appended above
            elif c3_empty:
                # Fallback: C3 empty pattern
                g2    = num(ws.cell(row=row, column=10))
                g2b_  = num(ws.cell(row=row, column=11))
                name2 = cv(ws.cell(row=row, column=12))
                if name1 and name2 and not name2.startswith('*'):
                    segs2 = _fmt_grams_segments(g2, g2b_, None)
                    n2_clean = name2.split('*')[0].strip()
                    full_name = f"{name1}  +  {n2_clean}"
                    left_opt['items'].append({'name': full_name, 'segs': segs2})
            else:
                item = _parse_bullet_row(ws, row, gram_cols=[3, 4], name_cols=range(5, 6))
                if item:
                    # Fix segs for unit-counted products (Biscotti, Uova) — no unit label
                    if _is_unit_product(item['name']):
                        g_base = num(ws.cell(row=row, column=3))
                        g_blu  = num(ws.cell(row=row, column=4))
                        item['segs'] = _fmt_unit_segments(g_base, g_blu)
                    # Check for kcal annotation in C7/C8 + C9='totali' (e.g. Biscotti, Muesli)
                    c9_str = str(ws.cell(row=row, column=9).value or '').strip().lower()
                    if c9_str in ('totali', 'tot', 'kcal'):
                        kc1 = num(ws.cell(row=row, column=7))
                        kc2 = num(ws.cell(row=row, column=8))
                        if kc1:
                            kstr = f"{int(kc1)} kcal"
                            if kc2 and kc2 != kc1: kstr += f" / {int(kc2)} kcal all."
                            item['name'] = item['name'] + f"  {kstr} totali"
                    # Annotazione da F (col 6) per opzioni sinistra (2/4)
                    annot_f = cv(ws.cell(row=row, column=6))
                    if annot_f and annot_f.lower() not in ('o', 'e', '+'):
                        item['name'] = (item['name'] + f'  {annot_f}').strip() if item['name'] else annot_f
                    left_opt['items'].append(item)

        # ── Bullet on RIGHT (col M = '°') ─────────────────────────────────────
        if m == '°' and right_opt is not None:
            item = _parse_bullet_row(ws, row, gram_cols=[14, 15], name_cols=range(16, 17))
            if item:
                if _is_unit_product(item['name']):
                    g_base = num(ws.cell(row=row, column=14))
                    g_blu  = num(ws.cell(row=row, column=15))
                    item['segs'] = _fmt_unit_segments(g_base, g_blu)
                # Annotazione da Q (col 17) per opzioni destra (3/5)
                annot_q = cv(ws.cell(row=row, column=17))
                if annot_q and annot_q.lower() not in ('o', 'e', '+'):
                    item['name'] = (item['name'] + f'  {annot_q}').strip() if item['name'] else annot_q
                right_opt['items'].append(item)

    # Finalizza single_header_parts per OPZIONE 1
    for opt in [left_opt, right_opt]:
        if opt and 'single_header_parts' in opt:
            parts = opt.pop('single_header_parts', [])
            q = opt.pop('single_header_q', '')
            if q:
                parts.append(q)
            if parts:
                opt['header_item'] = '  '.join(parts)

    if left_opt:  options.append(left_opt)
    if right_opt: options.append(right_opt)

    # Move header_item / header_items to front of items list
    for opt in options:
        # header_items: lista di righe bold (usata da OPZIONE 1)
        his = opt.pop('header_items', None)
        if his:
            for hi in reversed(his):
                opt['items'].insert(0, '__HDR__ ' + hi)
        # header_item: singola riga bold (usata da OPZIONE 2/3/4/5)
        hi = opt.pop('header_item', None)
        if hi:
            opt['items'].insert(0, '__HDR__ ' + hi)

    # Sort by option number
    def opt_num(o):
        import re
        mx = re.search(r'(\d+)', o['titolo'])
        return int(mx.group(1)) if mx else 99
    options.sort(key=opt_num)
    return options


def _fmt_grams(g_base, g_blu, g_verde):
    """Format up to 3 gram values → plain string (for data storage)."""
    g_base  = num_raw(g_base)
    g_blu   = num_raw(g_blu)
    g_verde = num_raw(g_verde)
    if g_base is None and g_blu is None and g_verde is None:
        return ''
    parts = []
    if g_base  is not None and g_base  > 0: parts.append(f"{fmt_g(g_base)} g")
    if g_blu   is not None and g_blu   > 0 and g_blu   != g_base:  parts.append(f"{fmt_g(g_blu)} g all.")
    if g_verde is not None and g_verde > 0 and g_verde != g_base and g_verde != g_blu: parts.append(f"{fmt_g(g_verde)} g all.2")
    return ' / '.join(parts) if parts else ''


def _fmt_grams_segments(g_base, g_blu, g_verde):
    """Return list of (text, style) where style is 'normal','italic','bold'.
    Used by draw_segments() for Opzione B rendering."""
    g_base  = num_raw(g_base)
    g_blu   = num_raw(g_blu)
    g_verde = num_raw(g_verde)
    segs = []
    if g_base is not None and g_base > 0:
        segs.append((f"{fmt_g(g_base)} g", 'normal'))
    if g_blu is not None and g_blu > 0 and g_blu != g_base:
        if segs: segs.append((' / ', 'normal'))
        segs.append((f"{fmt_g(g_blu)} g all.", 'italic'))
    if g_verde is not None and g_verde > 0 and g_verde != g_base and g_verde != g_blu:
        if segs: segs.append((' / ', 'normal'))
        segs.append((f"{fmt_g(g_verde)} g all.2", 'bold'))
    # if only allenamento value exists (base=0), show it without "0 g"
    if not segs and g_blu is not None and g_blu > 0:
        segs.append((f"{fmt_g(g_blu)} g all.", 'italic'))
    if not segs and g_verde is not None and g_verde > 0:
        segs.append((f"{fmt_g(g_verde)} g all.2", 'bold'))
    return segs


def num_raw(val):
    """Convert raw cell value (not cell object) to float or None."""
    if val is None: return None
    if str(val).strip() in ERRORS: return None
    try: return float(val)
    except (ValueError, TypeError): return None


def _parse_bullet_row(ws, row, gram_cols, name_cols):
    """Parse a bullet row → dict {'name': str, 'segs': [(txt,style),...]} or None."""
    name, segs = _parse_bullet_row_segs(ws, row, gram_cols, name_cols)
    if not name and not segs:
        return None
    return {'name': name, 'segs': segs}


def _parse_bullet_row_full(ws, row, gram_cols, name_col_primary, name_col_extra):
    """Like _parse_bullet_row but with extended name. Returns dict or None."""
    name, segs = _parse_bullet_row_full_segs(ws, row, gram_cols, name_col_primary, name_col_extra)
    if not name and not segs:
        return None
    return {'name': name, 'segs': segs}



# Prodotti misurati in kcal (non grammi) negli spuntini
KCAL_PRODUCTS = {'barretta proteica', 'budino proteico', 'chrecker', 'biscotti'}

def _is_kcal_product(name):
    """Return True if this product is measured in kcal rather than grams."""
    return any(k in name.lower() for k in KCAL_PRODUCTS)

def _fmt_kcal_segments(v_base, v_blu):
    """Format kcal values as styled segments."""
    v_base = num_raw(v_base)
    v_blu  = num_raw(v_blu)
    segs = []
    if v_base is not None and v_base > 0:
        segs.append((f"{fmt_g(v_base)} kcal", 'normal'))
    if v_blu is not None and v_blu > 0 and v_blu != v_base:
        if segs: segs.append((' / ', 'normal'))
        segs.append((f"{fmt_g(v_blu)} kcal all.", 'italic'))
    if not segs and v_blu is not None and v_blu > 0:
        segs.append((f"{fmt_g(v_blu)} kcal all.", 'italic'))
    return segs

# Prodotti misurati in pezzi/unità (senza etichetta di misura)
UNIT_PRODUCTS = {'biscotti', 'uova'}

def _is_unit_product(name):
    return any(k in name.lower() for k in UNIT_PRODUCTS)

def _fmt_unit_segments(v_base, v_blu):
    v_base = num_raw(v_base); v_blu = num_raw(v_blu); segs = []
    if v_base is not None and v_base > 0:
        segs.append((f"{fmt_g(v_base)}", 'normal'))
    if v_blu is not None and v_blu > 0 and v_blu != v_base:
        if segs: segs.append((' / ', 'normal'))
        segs.append((f"{fmt_g(v_blu)} all.", 'italic'))
    if not segs and v_blu is not None and v_blu > 0:
        segs.append((f"{fmt_g(v_blu)} all.", 'italic'))
    return segs

def _read_spuntino_options(ws, row_start, row_end):
    """Parse spuntino bullet options. Returns list of dicts {name, segs}."""
    SKIP_WORDS = {'o', 'e', 'tot', 'totali', 'oppure', '+'}
    items = []
    i = row_start

    while i <= row_end:
        b_raw = ws.cell(row=i, column=2).value
        b_str = str(b_raw).strip() if b_raw is not None else ''

        if b_str == '°':
            g1  = num(ws.cell(row=i, column=3))
            g1b = num(ws.cell(row=i, column=4))

            # Name1: cols 5..6 only (main name before connector)
            name1_parts = []
            for col in range(5, 7):
                v = cv(ws.cell(row=i, column=col))
                if not v or v.lower().strip() in SKIP_WORDS or v.startswith('*'): continue
                try: float(v); continue
                except ValueError: pass
                name1_parts.append(v)
            name1 = '  '.join(name1_parts[:2])

            # Second compound part: look for connector ('e','o','+') then gram value
            # OR implicit second component in cols 10-12 (base=J, blu=K, name=L)
            g2 = g2b = None
            name2 = ''
            connector_used = '+'   # default separator for full_name
            trailing_text = ''     # e.g. "e una delle seguenti opzioni:"
            # Strategy 1: explicit connector in col F or G
            for connector_col in [6, 7]:
                connector = cv(ws.cell(row=i, column=connector_col))
                if connector and connector.lower().strip() in ('e', 'o', '+'):
                    connector_used = connector.strip()
                    gc = connector_col + 1
                    # even if gram=0, look for name
                    v2 = num(ws.cell(row=i, column=gc))
                    g2 = v2 if (v2 is not None and v2 > 0) else None
                    g2b_raw = num(ws.cell(row=i, column=gc+1))
                    g2b = g2b_raw if g2b_raw and g2b_raw > 0 and g2b_raw != g2 else None
                    n2_parts = []
                    for col in range(gc+1, min(gc+5, 15)):
                        t = cv(ws.cell(row=i, column=col))
                        if not t or t.lower().strip() in SKIP_WORDS or t.startswith('*'): continue
                        try: float(t); continue
                        except ValueError: pass
                        n2_parts.append(t)
                    name2 = '  '.join(n2_parts[:1])
                    # Read trailing text from col 11 (e.g. "e una delle seguenti opzioni:")
                    c11 = cv(ws.cell(row=i, column=11))
                    if c11 and c11.lower().strip() not in SKIP_WORDS:
                        trailing_text = c11.strip()
                    break
            # Strategy 2: implicit second component in cols J(10)/K(11)/L(12) — no connector
            if not name2:
                j2 = num(ws.cell(row=i, column=10))   # base (often 0)
                k2 = num(ws.cell(row=i, column=11))   # alleno
                l2 = cv(ws.cell(row=i, column=12))    # name
                if l2 and not l2.startswith('*') and (k2 is not None and k2 >= 0):
                    g2  = j2 if (j2 is not None and j2 > 0) else None
                    g2b = k2 if (k2 is not None and k2 > 0) else None
                    name2 = l2.split('*')[0].strip()
            # Strategy 3: pomeriggio pattern — C8=base, C9=all, C10=name (no connector col)
            # Used when cols 6 and 7 are empty/numeric and col 10 has text name
            if not name2:
                h8 = num(ws.cell(row=i, column=8))
                h9 = num(ws.cell(row=i, column=9))
                h10 = cv(ws.cell(row=i, column=10))
                # Check that col 6 and 7 are not connectors (already ruled out by strategy 1)
                # and col 10 contains a text name (not a number, not starting with *)
                if h10 and not h10.startswith('*') and (h8 is not None or h9 is not None):
                    try:
                        float(h10)  # if numeric, skip
                    except (ValueError, TypeError):
                        g2  = h8 if (h8 is not None and h8 > 0) else None
                        g2b = h9 if (h9 is not None and h9 > 0) else None
                        name2 = h10.split('*')[0].strip()

            if (g1 is not None and g1 > 0 and name1) or (name1 and _is_kcal_product(name1)):
                # Use kcal units for products like Barretta, Budino, Chrecker
                if _is_kcal_product(name1):
                    segs1 = _fmt_kcal_segments(g1, g1b)
                elif _is_unit_product(name1):
                    segs1 = _fmt_unit_segments(g1, g1b)
                else:
                    segs1 = _fmt_grams_segments(g1, g1b, None)
                has_second = name2 and (g2 or g2b)
                sep_label = f'  {connector_used}  '
                if has_second:
                    segs2 = _fmt_grams_segments(g2, g2b, None)
                    if segs2:
                        all_segs = segs1 + [(sep_label, 'normal')] + segs2
                    else:
                        all_segs = segs1
                    full_name = f"{name1}{sep_label}{name2}"
                else:
                    all_segs = segs1
                    full_name = name1
                if trailing_text:
                    full_name = full_name + f'  {trailing_text}'
                items.append({'name': full_name, 'segs': all_segs})
            elif name1:
                items.append({'name': name1, 'segs': []})

            # Sub-options: label in col D (mattina) or col C (pomeriggio)
            sub_items = []
            j = i + 1
            while j <= row_end:
                found = False
                for sc in [4, 3]:
                    slv = cv(ws.cell(row=j, column=sc))
                    if slv in ('a)', 'b)', 'c)', 'd)', 'e)', 'f)'):
                        sg  = num(ws.cell(row=j, column=sc+1))
                        sgb = num(ws.cell(row=j, column=sc+2))
                        sn_parts = []
                        for col in range(sc+2, sc+6):
                            t = cv(ws.cell(row=j, column=col))
                            if not t or t.lower().strip() in SKIP_WORDS or t.startswith('*'): continue
                            try: float(t); continue
                            except ValueError: pass
                            sn_parts.append(t)
                        sn = '  '.join(sn_parts[:1])
                        if sn:
                            gstr = _fmt_grams(sg, sgb, None)
                            sub_items.append(f"{slv} {gstr}  {sn}" if gstr else f"{slv} {sn}")
                        found = True
                        break
                if not found:
                    break
                j += 1

            if sub_items and items:
                suffix = "   ->  " + "  |  ".join(sub_items)
                items[-1]['name'] = items[-1]['name'] + suffix
                i = j
                continue

        i += 1
    return items

def _read_pasto_options(ws, carbo_start, carbo_end, mix_start, mix_end):
    """
    Parse carbo list, protein columns, and mix proteici.
    NOTE: In this Excel, LATTICINI/UOVA and CARNE sections fall WITHIN the mix range
    (rows 79-101 for pranzo, 154-175 for cena). We must read proteins from the full
    range carbo_start..mix_end, using col N as the authoritative protein column.
    Mix proteici are identified by col B='°' AND col C being a named recipe (not a number).
    Returns: (carbo_list, prot_dict, mix_list)
    """
    carbo = []
    prot = {'legumi': [], 'pesce': [], 'latticini': [], 'carne': [], 'note_carne': ''}
    mix = []
    current_prot_section = None
    current_mix_entry = None

    for row in range(carbo_start, mix_end + 1):
        b = cv(ws.cell(row=row, column=2))

        # ── CARBOIDRATI: bullet in col B, grams in C/D/E, name in F+G ──────────
        if b == '°' and row <= carbo_end:
            item = _parse_bullet_row_full(ws, row, gram_cols=[3, 4, 5],
                                          name_col_primary=range(6, 7),
                                          name_col_extra=range(6, 12))
            if item:
                if _is_unit_product(item['name']):
                    g_base = num(ws.cell(row=row, column=3))
                    g_blu  = num(ws.cell(row=row, column=4))
                    item['segs'] = _fmt_unit_segments(g_base, g_blu)
                carbo.append(item)

        # ── PROTEINE: section header in col N or O ────────────────────────────────
        n_raw   = cv(ws.cell(row=row, column=14)) or cv(ws.cell(row=row, column=15))
        n_upper = n_raw.upper() if n_raw else ''
        if 'LEGUMI' in n_upper:
            current_prot_section = 'legumi'
        elif 'PESCE' in n_upper:
            current_prot_section = 'pesce'
        elif 'LATTICINI' in n_upper or 'UOVA' in n_upper:
            current_prot_section = 'latticini'
        elif 'CARNE' in n_upper:
            current_prot_section = 'carne'
        elif 'PASTI A SETTIMANA' in n_upper or 'POSSIBILE NON' in n_upper:
            prot['note_carne'] = n_raw

        # Protein value: col N=base gram (numeric), O=blu, P=verde, Q+R=name
        n_g1 = num(ws.cell(row=row, column=14))
        n_g2 = num(ws.cell(row=row, column=15))
        n_g3 = num(ws.cell(row=row, column=16))
        name_parts = []
        for col in range(17, 25):
            v = cv(ws.cell(row=row, column=col))
            if not v: continue
            try: float(v); continue
            except ValueError: pass
            if v.startswith('*') or v.lower().startswith('o altra'): 
                # append as clarification in parens
                if name_parts: name_parts[-1] += f" ({v.strip()})"
                continue
            name_parts.append(v)
        q_name = ',  '.join(name_parts) if len(name_parts) > 1 else (''.join(name_parts))
        # BUG1 FIX: show row when q_name exists even if all gram cols are #N/A (→ None).
        # Old guard "if n_g1 and q_name" failed when n_g1=None due to '#N/A' string in cell.
        if q_name and current_prot_section:
            if _is_unit_product(q_name):
                segs = _fmt_unit_segments(n_g1, n_g2)
            else:
                segs = _fmt_grams_segments(n_g1, n_g2, n_g3)
            prot[current_prot_section].append({'name': q_name, 'segs': segs})

        # ── MIX PROTEICI: bullet in col B, col C = recipe name (text) or grams ──
        if b == '°' and row >= mix_start:
            c_val = ws.cell(row=row, column=3).value
            try:
                g1 = float(c_val) if c_val is not None else None
                is_named = False
            except (ValueError, TypeError):
                g1 = None
                is_named = bool(c_val and str(c_val).strip())

            if is_named:
                if current_mix_entry: mix.append(current_mix_entry)
                mix_name = str(c_val).strip()
                g_e  = num(ws.cell(row=row, column=5))
                ing_h = cv(ws.cell(row=row, column=8))
                if g_e and ing_h:
                    current_mix_entry = f"{mix_name}  {fmt_g(g_e)} g {ing_h}"
                else:
                    current_mix_entry = mix_name
            elif g1 is not None:
                if current_mix_entry: mix.append(current_mix_entry); current_mix_entry = None
                f_val = cv(ws.cell(row=row, column=6))
                g2_val = num(ws.cell(row=row, column=9)) or num(ws.cell(row=row, column=10))
                l_val  = cv(ws.cell(row=row, column=12))
                if g1 and f_val:
                    entry = f"{fmt_g(g1)} g {f_val}"
                    if g2_val and l_val:
                        entry += f"  +  {fmt_g(g2_val)} g {l_val}"
                    mix.append(entry)

        elif current_mix_entry is not None and b != '°' and row >= mix_start:
            # Continuation row of named mix
            g_e   = num(ws.cell(row=row, column=5))
            ing_h = cv(ws.cell(row=row, column=8))
            if g_e and ing_h:
                current_mix_entry += f"  +  {fmt_g(g_e)} g {ing_h}"

    if current_mix_entry: mix.append(current_mix_entry)
    return carbo, prot, mix



def _read_esempi(ws, row_start, row_end):
    """Parse esempi settimanali. Returns list of day dicts.
    Gestisce sia layout vecchio (nome a destra di 2 col) sia nuovo (base/blu/verde + nome a 3 col).
    """
    esempi = []
    GIORNI_KEYWORDS = ['LUNEDÌ','LUNEDI','MARTEDÌ','MERCOLEDÌ','MERCOLEDI',
                       'GIOVEDÌ','GIOVEDI','VENERDÌ','VENERDI','SABATO','DOMENICA']

    def _first_name_right(row, col_start, max_scan=5):
        """Return first non-numeric non-empty text value scanning right from col_start."""
        for dc in range(0, max_scan):
            v = cv(ws.cell(row=row, column=col_start + dc))
            if not v: continue
            try: float(v); continue
            except ValueError: pass
            return v
        return ''

    def _first_gram_at(row, col):
        """Return formatted gram string from col (base) + col+1 (blu) + col+2 (verde)."""
        g0 = num(ws.cell(row=row, column=col))
        g1 = num(ws.cell(row=row, column=col+1))
        g2 = num(ws.cell(row=row, column=col+2))
        # If col+1 or col+2 is actually a name (not numeric), ignore
        v1 = ws.cell(row=row, column=col+1).value
        v2 = ws.cell(row=row, column=col+2).value
        if v1 is not None:
            try: float(v1)
            except (TypeError, ValueError): g1 = None
        if v2 is not None:
            try: float(v2)
            except (TypeError, ValueError): g2 = None
        parts = []
        if g0: parts.append(f"{fmt_g(g0)} g")
        if g1 and g1 != g0: parts.append(f"{fmt_g(g1)} g all.")
        if g2 and g2 != g0 and g2 != g1: parts.append(f"{fmt_g(g2)} g all.2")
        return ' / '.join(parts)

    # Find rows containing giorno headers
    giorni_rows = []
    for row in range(row_start, row_end + 1):
        for col in range(1, 25):
            v = cv(ws.cell(row=row, column=col)).upper().strip()
            if any(v == g or v.startswith(g[:5]) for g in GIORNI_KEYWORDS):
                giorni_rows.append(row)
                break

    if not giorni_rows:
        return esempi

    for giorni_row in giorni_rows:
        # Collect (col, giorno_name) for this header row
        giorno_cols = []
        for col in range(1, 25):
            v = cv(ws.cell(row=giorni_row, column=col)).upper().strip()
            if any(v == g or v.startswith(g[:5]) for g in GIORNI_KEYWORDS):
                giorno_cols.append((col, v.title()))

        titoli_row = giorni_row + 1
        carbo_row = verdure_row = prot_row = None
        for row in range(giorni_row + 1, min(row_end + 1, giorni_row + 8)):
            a = cv(ws.cell(row=row, column=1)).upper()
            if 'CARBO' in a and carbo_row is None:    carbo_row = row
            elif 'VERDURE' in a and verdure_row is None: verdure_row = row
            elif 'PROTEINE' in a and prot_row is None: prot_row = row
            if carbo_row and verdure_row and prot_row: break

        for col, giorno in giorno_cols:
            titolo = cv(ws.cell(row=titoli_row, column=col))
            # Carbo
            c_g = _first_gram_at(carbo_row, col) if carbo_row else ''
            c_n = _first_name_right(carbo_row, col, max_scan=6) if carbo_row else ''
            # Verdure
            verd = cv(ws.cell(row=verdure_row, column=col)) if verdure_row else ''
            # Proteine
            p_g = _first_gram_at(prot_row, col) if prot_row else ''
            p_n = _first_name_right(prot_row, col, max_scan=6) if prot_row else ''

            if titolo or c_n or p_n:
                esempi.append({
                    'giorno': giorno,
                    'titolo': titolo,
                    'carbo_g': c_g, 'carbo_n': c_n,
                    'verdure': verd,
                    'prot_g': p_g, 'prot_n': p_n,
                })

    return esempi


# ─────────────────────────────────────────────────────────────────────────────
# PDF HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def rrect(c, x, y, w, h, r=3*mm, fill=WHITE, stroke=None, sw=0.5):
    c.saveState()
    c.setFillColor(fill)
    c.setStrokeColor(stroke if stroke else fill)
    c.setLineWidth(sw)
    p = c.beginPath(); p.roundRect(x, y, w, h, r)
    c.drawPath(p, fill=1, stroke=1 if stroke else 0)
    c.restoreState()

def pill(c, x, y, w, h, color):
    c.saveState()
    c.setFillColor(color); c.setStrokeColor(color)
    p = c.beginPath(); p.roundRect(x, y, w, h, h/2)
    c.drawPath(p, fill=1, stroke=0)
    c.restoreState()

def draw_header(c, d, page_num, total_pages):
    HEADER_H = 22*mm   # leggermente ridotta
    c.setFillColor(DARK); c.rect(0, H-HEADER_H, W, HEADER_H, fill=1, stroke=0)
    c.setFillColor(GREEN); c.rect(0, H-HEADER_H, 2*mm, HEADER_H, fill=1, stroke=0)

    # Row 1: brand — name — date (piu' in alto, vicino al bordo superiore)
    row1_y = H - 7*mm
    c.setFillColor(GREEN);   c.setFont("Helvetica-Bold", 11)
    c.drawString(8*mm, row1_y, "PIANO NUTRIZIONALE")
    bw = c.stringWidth("PIANO NUTRIZIONALE", "Helvetica-Bold", 11)
    # separator (la "|" rimane nella stessa posizione orizzontale)
    c.setFillColor(GRAY_TEXT)
    c.rect(8*mm + bw + 5*mm, row1_y - 1*mm, 0.4*mm, 8*mm, fill=1, stroke=0)
    c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 11)
    c.drawString(8*mm + bw + 10*mm, row1_y, d['nome'])
    nw = c.stringWidth(d['nome'], "Helvetica-Bold", 11)
    c.setFillColor(GRAY_MID); c.setFont("Helvetica", 10)
    c.drawString(8*mm + bw + 16*mm + nw, row1_y, d['data'])

    # Row 2: kcal + macros IN BASSO A DESTRA
    row2_y = H - HEADER_H + 6*mm
    items = [
        (f"\u26a1 {d['kcal']} kcal", "/ giorno", KCAL_TEXT, GRAY_MID),
        (d.get('prot_totali',''), "PROTEINE", GREEN, GRAY_MID),
    ]
    GAP = 8*mm
    sep_w = 4.4*mm
    widths = []
    for val, lbl, vc, lc in items:
        if not val: continue
        vw = c.stringWidth(val, "Helvetica-Bold", 9)
        lw = c.stringWidth(" " + lbl, "Helvetica", 8)
        widths.append((val, lbl, vc, lc, vw + lw))
    total_w = sum(w[4] for w in widths) + GAP*(len(widths)-1) + sep_w*(len(widths)-1)
    # Spostato in BASSO A DESTRA (non centrato)
    mx = W - total_w - 8*mm  # 8mm dal bordo destro
    for i, (val, lbl, vc, lc, tw) in enumerate(widths):
        vw = c.stringWidth(val, "Helvetica-Bold", 9)
        if i > 0:
            c.setFillColor(GRAY_TEXT)
            c.rect(mx, row2_y - 1*mm, 0.4*mm, 6*mm, fill=1, stroke=0)
            mx += sep_w
        c.setFillColor(vc); c.setFont("Helvetica-Bold", 9)
        c.drawString(mx, row2_y, val)
        c.setFillColor(lc); c.setFont("Helvetica", 8)
        c.drawString(mx + vw + 1.5*mm, row2_y, lbl)
        mx += tw + GAP

def draw_footer(c, page_num, total_pages, footer_notes=None, has_all1=True, has_all2=True):
    """
    Footer dinamico su sfondo scuro stile header.
    Ordine righe (dall'alto verso il basso):
      1. Legenda valori + note (greedy packing, possibile seconda riga)
      2. Separatore
      3. Nutrizionista  Elena Toschi  (bold, centrata) + pagina
    """
    LEG_SZ     = 7.5
    NOTE_SZ    = 7.0
    LINE_H     = 3*mm     # interlinea molto compatta
    PAD_BOT    = 3*mm     # spazio sotto riga nutrizionista
    PAD_SEP    = 1*mm     # spazio tra separatore e prima riga contenuto
    PAD_TOP    = 2*mm     # spazio sopra ultima riga contenuto
    SEP_H      = 0.3*mm
    LEFT_X     = 8*mm
    MAX_X      = W - 8*mm
    AVAIL_W    = MAX_X - LEFT_X
    BLUE_LIGHT = colors.HexColor("#5DADE2")

    def _sw(txt, fn, fs):  return c.stringWidth(txt, fn, fs)
    def _segs_w(segs):     return sum(_sw(t, f, s) for t, f, s, _ in segs)
    def _draw_segs(segs, x, y):
        for txt, fn, fs, col in segs:
            c.setFont(fn, fs); c.setFillColor(col)
            c.drawString(x, y, txt)
            x += _sw(txt, fn, fs)
        return x

    # ── Segmenti LEGENDA ──────────────────────────────────────────────────────
    show_legend = has_all1 or has_all2
    leg_segs = []
    if show_legend:
        leg_segs += [("Valori:  ", "Helvetica",        LEG_SZ, GRAY_MID),
                     ("normale",   "Helvetica",         LEG_SZ, WHITE)]
        if has_all1:
            lbl1 = "allenamento" if not has_all2 else "allenamento 1"
            leg_segs += [("  /  ", "Helvetica",         LEG_SZ, GRAY_MID),
                         (lbl1,    "Helvetica-Oblique",  LEG_SZ, BLUE_LIGHT)]
        if has_all2:
            leg_segs += [("  /  ",         "Helvetica",     LEG_SZ, GRAY_MID),
                         ("allenamento 2", "Helvetica-Bold", LEG_SZ, GREEN)]

    # ── Note come pezzi pronti ────────────────────────────────────────────────
    note_items = list(footer_notes) if footer_notes else []
    if not note_items:
        note_items = ["\u26a0  Prediligere prodotti senza glutine e senza lattosio"]

    sep_w = _sw("  •  ", "Helvetica", NOTE_SZ)
    note_pieces = []
    for note in note_items:
        segs = [("  •  ", "Helvetica", NOTE_SZ, GRAY_MID),
                (note,    "Helvetica", NOTE_SZ, KCAL_TEXT)]
        note_pieces.append((segs, sep_w + _sw(note, "Helvetica", NOTE_SZ)))

    # ── Greedy packing: legenda + note su quante righe bastano ────────────────
    content_rows = []
    cur_segs = list(leg_segs)
    cur_w    = _segs_w(leg_segs) if show_legend else 0

    for note_segs, nw in note_pieces:
        if cur_w + nw <= AVAIL_W:
            cur_segs.extend(note_segs); cur_w += nw
        else:
            if cur_segs: content_rows.append(cur_segs)
            cur_segs = list(note_segs); cur_w = nw
    if cur_segs: content_rows.append(cur_segs)

    n_content = len(content_rows)

    # ── Altezza footer ────────────────────────────────────────────────────────
    FOOTER_H = PAD_TOP + n_content * LINE_H + PAD_SEP + SEP_H + LINE_H + PAD_BOT
    FOOTER_H = max(FOOTER_H, 14*mm)

    # ── Sfondo + striscia verde ───────────────────────────────────────────────
    c.setFillColor(DARK);  c.rect(0, 0, W, FOOTER_H, fill=1, stroke=0)
    c.setFillColor(GREEN); c.rect(0, 0, 2*mm, FOOTER_H, fill=1, stroke=0)

    # ── Zone di layout ────────────────────────────────────────────────────────
    # Zona A (bottom): da 0 a sep_y  → Nutrizionista centrata verticalmente
    # Zona B (top):   da sep_y a FOOTER_H → righe contenuto centrate verticalmente
    sep_y    = PAD_BOT + LINE_H + PAD_SEP * 0.5   # posizione separatore
    zone_a_h = sep_y                                # altezza zona A
    zone_b_h = FOOTER_H - sep_y - SEP_H            # altezza zona B

    # ── Separatore ────────────────────────────────────────────────────────────
    c.setFillColor(GRAY_TEXT); c.rect(LEFT_X, sep_y, AVAIL_W, SEP_H, fill=1, stroke=0)

    # ── Zona A: Nutrizionista centrata verticalmente in zone_a_h ─────────────
    # baseline = centro zona A - metà cap-height (≈ font_size * 0.35)
    nutriz_y = zone_a_h / 2 - 9 * 0.35 / 2 * mm * 0.8
    c.setFillColor(WHITE);    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(W/2, nutriz_y, "Nutrizionista  Elena Toschi")
    c.setFillColor(GRAY_MID); c.setFont("Helvetica", 8)
    c.drawRightString(MAX_X, nutriz_y, f"{page_num} / {total_pages}")

    # ── Zona B: righe contenuto centrate verticalmente E orizzontalmente ────────
    # Le righe partono dall'alto della zona B (legenda per prima) e scendono
    content_block_h = n_content * LINE_H
    top_of_zone_b = sep_y + SEP_H + zone_b_h   # bordo superiore zona B
    first_row_y = top_of_zone_b - (zone_b_h - content_block_h) / 2 - LINE_H * 0.65
    row_y = first_row_y
    for row_segs in content_rows:
        row_w = _segs_w(row_segs)
        start_x = (W - row_w) / 2
        _draw_segs(row_segs, start_x, row_y)
        row_y -= LINE_H

    draw_footer._last_h = FOOTER_H

def sec_bar(c, x, y, title, icon, bg, w, kcal_txt=None, prot_txt=None):
    BAR_H   = 9*mm
    BAR_BOT = y - 7*mm    # bottom edge (same geometry as before)
    rrect(c, x, BAR_BOT, w, BAR_H, r=3*mm, fill=bg)
    # True vertical center: mid-point of the colored bar
    center_y = BAR_BOT + BAR_H / 2
    # Baseline = center - half of cap-height
    # cap-height ≈ 0.72 * font_size_pt; 1 pt = 0.3528 mm
    title_baseline = center_y - (11 * 0.72 * 0.3528 * mm) / 2
    right_baseline = center_y - ( 9 * 0.72 * 0.3528 * mm) / 2
    c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 11)
    c.drawString(x + 4*mm, title_baseline, title)
    rx = x + w - 3*mm
    if prot_txt:
        c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 9)
        c.drawRightString(rx, right_baseline, prot_txt)
        rx -= c.stringWidth(prot_txt, "Helvetica-Bold", 9) + 8*mm
    if kcal_txt:
        c.setFillColor(colors.HexColor("#FFD700")); c.setFont("Helvetica-Bold", 9)
        c.drawRightString(rx, right_baseline, kcal_txt)

def draw_segments(c, x, y, segs, font_sz, color_normal, color_italic=None, color_bold=None):
    """Draw (text, style) segments inline. Returns x after last segment."""
    if color_italic is None: color_italic = color_normal
    if color_bold   is None: color_bold   = color_normal
    for txt, style in segs:
        if style == 'italic':
            c.setFont("Helvetica-Oblique", font_sz)
            c.setFillColor(color_italic)
        elif style == 'bold':
            c.setFont("Helvetica-Bold", font_sz)
            c.setFillColor(color_bold)
        else:
            c.setFont("Helvetica", font_sz)
            c.setFillColor(color_normal)
        c.drawString(x, y, txt)
        x += c.stringWidth(txt, {
            'italic': 'Helvetica-Oblique',
            'bold':   'Helvetica-Bold',
        }.get(style, 'Helvetica'), font_sz)
    return x


def draw_wrapped(c, x, y, text, font_name, font_sz, max_w, line_h, color=None, indent=0):
    """Draw text with word-wrap. Returns new y after last line drawn."""
    if color: c.setFillColor(color)
    c.setFont(font_name, font_sz)
    words = str(text).split()
    line = ''
    first = True
    for word in words:
        test = (line + ' ' + word).strip()
        if c.stringWidth(test, font_name, font_sz) <= max_w:
            line = test
        else:
            if line:
                c.drawString(x if first else x + indent, y, line)
                y -= line_h
                first = False
            line = word
    if line:
        c.drawString(x if first else x + indent, y, line)
        y -= line_h
    return y


def _parse_bullet_row_segs(ws, row, gram_cols, name_cols):
    """Parse a bullet row → (name_str, gram_segs)."""
    g_base  = num(ws.cell(row=row, column=gram_cols[0])) if len(gram_cols) > 0 else None
    g_blu   = num(ws.cell(row=row, column=gram_cols[1])) if len(gram_cols) > 1 else None
    g_verde = num(ws.cell(row=row, column=gram_cols[2])) if len(gram_cols) > 2 else None
    name_parts = []
    for col in name_cols:
        v = cv(ws.cell(row=row, column=col))
        if not v: continue
        try: float(v); continue
        except ValueError: pass
        if v.strip().lower() in ('o', 'e', 'tot', 'totali'): continue
        if v.startswith('*') or v.startswith('('): continue
        name_parts.append(v)
    name = '  '.join(name_parts[:3])
    segs = _fmt_grams_segments(g_base, g_blu, g_verde)
    return name, segs


def _parse_bullet_row_segs(ws, row, gram_cols, name_cols):
    """Parse a bullet row → (name_str, gram_segs)."""
    g_base  = num(ws.cell(row=row, column=gram_cols[0])) if len(gram_cols) > 0 else None
    g_blu   = num(ws.cell(row=row, column=gram_cols[1])) if len(gram_cols) > 1 else None
    g_verde = num(ws.cell(row=row, column=gram_cols[2])) if len(gram_cols) > 2 else None
    name_parts = []
    for col in name_cols:
        v = cv(ws.cell(row=row, column=col))
        if not v: continue
        try: float(v); continue
        except ValueError: pass
        if v.strip().lower() in ('o', 'e', 'tot', 'totali'): continue
        if v.startswith('*') or v.startswith('('): continue
        name_parts.append(v)
    name = '  '.join(name_parts[:3])
    segs = _fmt_grams_segments(g_base, g_blu, g_verde)
    return name, segs


def _parse_bullet_row_full_segs(ws, row, gram_cols, name_col_primary, name_col_extra):
    """Like _parse_bullet_row_full but returns (name_str, gram_segs)."""
    g_base  = num(ws.cell(row=row, column=gram_cols[0])) if len(gram_cols) > 0 else None
    g_blu   = num(ws.cell(row=row, column=gram_cols[1])) if len(gram_cols) > 1 else None
    g_verde = num(ws.cell(row=row, column=gram_cols[2])) if len(gram_cols) > 2 else None
    name_parts = []
    for col in name_col_extra:
        v = cv(ws.cell(row=row, column=col))
        if not v: continue
        try: float(v); continue
        except ValueError: pass
        if v.strip().lower() in ('o', 'e', 'tot', 'totali'): continue
        if v.startswith('*') or v.startswith('('): continue
        name_parts.append(v)
    name = ',  '.join(name_parts) if len(name_parts) > 1 else (''.join(name_parts))
    segs = _fmt_grams_segments(g_base, g_blu, g_verde)
    return name, segs


# Colors for Opzione B styled values
COL_NORMAL = None   # resolved at draw time from DARK
COL_ITALIC = colors.HexColor("#0070C0")   # blue for all.1 (same as Excel training color)
COL_BOLD   = colors.HexColor("#008E40")   # green for all.2 (same as Excel training color)


def draw_spuntino_item(c, x, y, item, col_w, dot_color, font_sz=7, line_h=5.5):
    """Draw a spuntino bullet item. If name contains ' -> ', splits into main line + sub-options."""
    from reportlab.lib.units import mm as _mm
    LH = line_h * _mm

    if isinstance(item, dict):
        name = item['name']
        segs = item['segs']
    else:
        name = str(item)
        segs = []

    # Detect sub-options pattern: "main part   ->  a) ... | b) ..."
    if '   ->  ' in name:
        main_part, sub_part = name.split('   ->  ', 1)
        sub_opts = [s.strip() for s in sub_part.split('  |  ')]
    else:
        main_part = name
        sub_opts = []

    # Draw bullet + segs + main name
    c.setFillColor(dot_color)
    c.circle(x + 2*_mm, y + 1.3*_mm, 0.8*_mm, fill=1, stroke=0)
    tx = x + 4.5*_mm
    if segs:
        tx = draw_segments(c, tx, y, segs, font_sz, DARK, COL_ITALIC, COL_BOLD)
        c.setFont("Helvetica", font_sz); c.setFillColor(DARK)
        c.drawString(tx, y, "  ")
        tx += c.stringWidth("  ", "Helvetica", font_sz)
    avail_w = col_w - (tx - x) - 2*_mm
    y = draw_wrapped(c, tx, y, main_part, "Helvetica", font_sz, avail_w, line_h, DARK, indent=2*_mm)

    # Draw sub-options indented
    if sub_opts:
        indent_x = x + 8*_mm
        sub_w = col_w - 10*_mm
        y -= 1.5*_mm  # extra gap before first sub-option
        for sub in sub_opts:
            c.setFillColor(DARK)
            c.setFont("Helvetica", font_sz - 0.5)
            y = draw_wrapped(c, indent_x, y, sub, "Helvetica", font_sz - 0.5,
                             sub_w, line_h + 0.5, DARK, indent=3*_mm)

    return y


def draw_bullet_styled(c, x, y, name, segs, col_w, dot_color, font_sz=6.5, line_h=4.5):
    """Draw one bullet with styled gram segments + name with word-wrap. Returns new y (in mm)."""
    from reportlab.lib.units import mm
    c.setFillColor(dot_color)
    c.circle(x + 2*mm, y + 1.2*mm, 0.7*mm, fill=1, stroke=0)
    tx = x + 4.5*mm
    if segs:
        tx = draw_segments(c, tx, y, segs, font_sz, DARK, COL_ITALIC, COL_BOLD)
        c.setFont("Helvetica", font_sz); c.setFillColor(DARK)
        c.drawString(tx, y, "  ")
        tx += c.stringWidth("  ", "Helvetica", font_sz)
    # Wrapped name
    max_w = col_w - (tx - x)
    new_y = draw_wrapped(c, tx, y, name, "Helvetica", font_sz, max_w, line_h*mm, DARK, indent=2*mm)
    return new_y


def draw_bullet_list(c, x, y, items, cw, dot_color, font_sz=6.5, line_h=4.5*mm):
    """Draw a bullet list. Items can be dicts {'name','segs'} or plain strings. Returns new y."""
    for item in items:
        c.setFillColor(dot_color); c.circle(x+2*mm, y+1.2*mm, 0.7*mm, fill=1, stroke=0)
        if isinstance(item, dict):
            y = draw_bullet_styled(c, x, y, item['name'], item['segs'], cw, dot_color, font_sz, line_h/mm)
        else:
            y = draw_wrapped(c, x+4.5*mm, y, str(item), "Helvetica", font_sz,
                             cw - 5*mm, line_h, DARK, indent=2*mm)
    return y

def draw_protein_table(c, x, y, CW, prot_dict, carbo_list=None, pb=None):
    """Draw combined carbo + protein table. Returns new y.
    If pb (PageBuilder) is passed, performs automatic page breaks between rows."""
    if carbo_list:
        carbo_w = CW * 0.28   # slightly wider to fit 3 gram values
        prot_w  = CW - carbo_w - 3*mm
        prot_x  = x + carbo_w + 3*mm
    else:
        carbo_w = 0
        prot_w  = CW
        prot_x  = x

    sub_cols = []
    if prot_dict['legumi']:
        sub_cols.append(('\U0001f331 Legumi & Vegetali', BROWN,  prot_dict['legumi']))
    if prot_dict['pesce']:
        sub_cols.append(('\U0001f41f Pesce',              BLUE,   prot_dict['pesce']))
    if prot_dict['latticini']:
        sub_cols.append(('\U0001f9c0 Latticini & Uova',   ORANGE, prot_dict['latticini']))
    if prot_dict['carne']:
        sub_cols.append(('\U0001f969 Carne',              RED,    prot_dict['carne']))

    if not sub_cols:
        return y

    sub_w = (prot_w - (len(sub_cols)-1)*3*mm) / max(len(sub_cols), 1)
    rh = 5*mm
    HEADER_H = 17*mm

    def _draw_headers(y_pos):
        rrect(c, prot_x, y_pos-6.5*mm, prot_w, 7*mm, r=3*mm, fill=PROT_COLOR)
        c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(prot_x+prot_w/2, y_pos-3.5*mm, "PROTEINE")
        if carbo_list:
            rrect(c, x, y_pos-6.5*mm, carbo_w, 7*mm, r=3*mm, fill=GREEN_DARK)
            c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 9)
            c.drawCentredString(x+carbo_w/2, y_pos-3.5*mm, "CARBOIDRATI")
        y2 = y_pos-8.5*mm
        for si, (sh, sc, _) in enumerate(sub_cols):
            sx = prot_x+si*(sub_w+3*mm)
            rrect(c, sx, y2-6*mm, sub_w, 6.5*mm, r=2*mm, fill=sc)
            c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 6.8)
            c.drawCentredString(sx+sub_w/2, y2-3.2*mm, sh)
        return y2-8*mm

    n_rows = max(
        len(carbo_list) if carbo_list else 0,
        max((len(ci[2]) for ci in sub_cols), default=0)
    )

    # ── New layout: grammi su riga 1 (full width), nome su riga 2 sotto ─────
    FONT_SZ    = 5.5
    LH_NAME    = 2.8*mm   # v20: Aumentato per maggiore spaziatura tra le righe di testo
    GAP_SEG_NAME = 2.8*mm # v20: STESSO valore di LH_NAME per spaziatura uniforme
    PAD_TOP    = 1.5*mm   # v20: Aumentato - contenuto parte dall'alto della cella
    PAD_BOT    = 1.5*mm   # v20: Aumentato per equilibrio visivo

    def _count_name_lines(name, cell_w):
        words = name.split()
        lines, line = 1, ''
        for w in words:
            test = (line + ' ' + w).strip()
            if c.stringWidth(test, "Helvetica", FONT_SZ) > cell_w - 4*mm and line:
                lines += 1; line = w
            else:
                line = test
        return lines

    def _row_height(row_idx):
        name_lines = 1
        cells = []
        if carbo_list and row_idx < len(carbo_list):
            cells.append((carbo_list[row_idx], carbo_w))
        for _, _, items in sub_cols:
            if row_idx < len(items):
                cells.append((items[row_idx], sub_w))
        for item, cell_w in cells:
            nm = item['name'] if isinstance(item, dict) else str(item)
            name_lines = max(name_lines, _count_name_lines(nm, cell_w))
        
        # v20: Altezza calcolata in base al numero di righe + minimo più generoso
        calculated_h = PAD_TOP + GAP_SEG_NAME + (name_lines - 1) * LH_NAME + LH_NAME + PAD_BOT
        MIN_ROW_H = 9*mm  # v20: Aumentato da 7mm a 9mm per maggiore spazio verticale
        return max(calculated_h, MIN_ROW_H)

    needed = HEADER_H + sum(_row_height(r) for r in range(min(n_rows, 5)))
    if pb and pb.need_space(needed):
        pb.new_page(); y = pb.y

    y = _draw_headers(y)

    for row in range(n_rows):
        rh = _row_height(row)
        # Aggiorna pb.y prima del check, così need_space usa la y reale corrente
        if pb: pb.y = y
        if pb and pb.need_space(rh + 1*mm):
            pb.new_page(); y = pb.y
            y = _draw_headers(y)

        bg = GRAY_LIGHT if row % 2 == 0 else WHITE

        def _draw_cell(x0, cell_w, item, dot_color):
            rrect(c, x0, y-rh, cell_w, rh, r=0.5*mm, fill=bg)
            if item is None:
                return
            # Line 1: bullet + grammature
            seg_y = y - PAD_TOP - GAP_SEG_NAME + 1.0*mm
            c.setFillColor(dot_color)
            c.circle(x0 + 2*mm, seg_y + 0.8*mm, 0.6*mm, fill=1, stroke=0)
            tx = x0 + 4.5*mm
            if isinstance(item, dict) and item['segs']:
                tx = draw_segments(c, tx, seg_y, item['segs'], FONT_SZ, DARK, COL_ITALIC, COL_BOLD)
            
            # Testo nome - try to fit on same line as segs if there's space
            name = item['name'] if isinstance(item, dict) else str(item)
            name_x = tx + 1.5*mm
            avail_w_same_line = x0 + cell_w - 2*mm - name_x
            
            # Check if name fits on one line next to segs
            c.setFont("Helvetica", FONT_SZ)
            name_w = c.stringWidth(name, "Helvetica", FONT_SZ)
            
            # v19: Rimossa condizione "and ' ' not in name" - se il nome sta in larghezza, va sulla stessa riga
            if name_w <= avail_w_same_line:
                # Name fits on same line as segs
                c.setFillColor(DARK)
                c.drawString(name_x, seg_y, name)
            else:
                # Nome non sta sulla stessa riga dei segs - va wrappato
                # v19 FIX: Logica semplificata con spacing consistente
                
                # Calcola posizione Y iniziale per il nome (sotto i segs)
                name_y_start = seg_y - GAP_SEG_NAME
                
                # Wrappa tutte le parole con larghezza piena cella
                words = name.split()
                lines = []
                current_line = ''
                max_name_w = cell_w - 6*mm  # Larghezza per il nome (con margini)
                
                for word in words:
                    test = (current_line + ' ' + word).strip() if current_line else word
                    test_w = c.stringWidth(test, "Helvetica", FONT_SZ)
                    if test_w <= max_name_w:
                        current_line = test
                    else:
                        if current_line:
                            lines.append(current_line)
                        current_line = word
                
                if current_line:
                    lines.append(current_line)
                
                # Disegna tutte le righe con spacing consistente
                c.setFillColor(DARK)
                c.setFont("Helvetica", FONT_SZ)
                name_x_start = x0 + 3*mm
                
                for i, line_text in enumerate(lines):
                    line_y = name_y_start - (i * LH_NAME)
                    c.drawString(name_x_start, line_y, line_text)

        if carbo_list:
            item = carbo_list[row] if row < len(carbo_list) else None
            _draw_cell(x, carbo_w, item, GREEN_DARK)

        for si, (_, sc, items) in enumerate(sub_cols):
            sx = prot_x + si * (sub_w + 3*mm)
            item = items[row] if row < len(items) else None
            _draw_cell(sx, sub_w, item, sc)

        y -= rh

    if pb: pb.y = y
    return y

def draw_esempi_table(c, x, y, CW, esempi, lbl_color, bg_color):
    """Draw weekly examples table with dynamic row height. Returns new y."""
    if not esempi:
        return y

    n     = min(len(esempi), 7)
    cw7   = CW / n
    CELL_W = cw7 - 0.6*mm     # larghezza interna cella
    PAD   = 2.5*mm             # padding interno
    TITLE_SZ  = 6; TITLE_LH = 3.2*mm
    GRAM_SZ   = 5.5; GRAM_LH = 3*mm
    HEADER_H  = 6.5*mm

    def _wrap_centered(text, font, sz, max_w):
        """Wrappa il testo e restituisce lista di righe."""
        words = text.split(); lines = []; line = ''
        for w in words:
            test = (line + ' ' + w).strip()
            if c.stringWidth(test, font, sz) <= max_w: line = test
            else:
                if line: lines.append(line)
                line = w
        if line: lines.append(line)
        return lines or ['']

    def _cell_height(es):
        """Calcola l'altezza necessaria per una cella."""
        title_lines = _wrap_centered(es['titolo'], "Helvetica-Bold", TITLE_SZ, CELL_W - 2*PAD)
        h = PAD + len(title_lines) * TITLE_LH
        for g_val, g_name in [(es['carbo_g'], es['carbo_n']), (es['prot_g'], es['prot_n'])]:
            # Se il numero è vuoto (barrato), non mostrare nemmeno l'unità di misura e il nome
            if not g_val:
                continue
            # g_val già contiene le unità (es. "240 g / 430 g all."), non aggiungere " g " extra
            graw = f"{g_val} {g_name}".strip()
            if graw:
                glines = _wrap_centered(graw, "Helvetica", GRAM_SZ, CELL_W - 2*PAD)
                h += len(glines) * GRAM_LH
        h += PAD
        return max(h, 28*mm)  # Aumentato da 18mm a 28mm per più spazio

    ROW_H = max(_cell_height(es) for es in esempi[:n])

    # ── Intestazioni giorni ───────────────────────────────────────────────────
    for i, es in enumerate(esempi[:n]):
        giorno = es['giorno'][:3].upper()
        bg = GREEN if i < 5 else ORANGE
        rrect(c, x+i*cw7+0.3*mm, y-HEADER_H+0.3*mm, cw7-0.6*mm, HEADER_H-0.3*mm, r=2*mm, fill=bg)
        c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 7)
        c.drawCentredString(x+i*cw7+cw7/2, y-HEADER_H*0.45, giorno)
    y -= HEADER_H

    # ── Celle contenuto ───────────────────────────────────────────────────────
    for i, es in enumerate(esempi[:n]):
        cx      = x + i*cw7 + 0.3*mm
        cell_cx = cx + CELL_W/2
        rrect(c, cx, y-ROW_H+0.3*mm, CELL_W, ROW_H-0.3*mm,
              r=2*mm, fill=bg_color, stroke=GRAY_MID, sw=0.3)

        ly = y - PAD
        # Titolo bold wrappato
        title_lines = _wrap_centered(es['titolo'], "Helvetica-Bold", TITLE_SZ, CELL_W - 2*PAD)
        for tl in title_lines:
            c.setFillColor(lbl_color); c.setFont("Helvetica-Bold", TITLE_SZ)
            c.drawCentredString(cell_cx, ly, tl)
            ly -= TITLE_LH

        # Grammature wrappate
        for g_val, g_name in [(es['carbo_g'], es['carbo_n']), (es['prot_g'], es['prot_n'])]:
            # Se il numero è vuoto (barrato), non mostrare nemmeno l'unità di misura e il nome
            if not g_val:
                continue
            # g_val già contiene le unità (es. "240 g / 430 g all."), non aggiungere " g " extra
            graw = f"{g_val} {g_name}".strip()
            if not graw: continue
            glines = _wrap_centered(graw, "Helvetica", GRAM_SZ, CELL_W - 2*PAD)
            for gl in glines:
                c.setFillColor(GRAY_TEXT); c.setFont("Helvetica", GRAM_SZ)
                c.drawCentredString(cell_cx, ly, gl)
                ly -= GRAM_LH

    y -= ROW_H + 1.5*mm
    return y


# ─────────────────────────────────────────────────────────────────────────────
# PAGE BUILDER
# ─────────────────────────────────────────────────────────────────────────────
class PageBuilder:
    """Handles multi-page layout with automatic page breaks."""

    def __init__(self, canvas_obj, d, total_pages):
        self.c = canvas_obj
        self.d = d
        self.total_pages = total_pages
        self.page_num = 0
        self.M = 10*mm
        self.CW = W - 2*self.M
        self.y = 0
        self.MIN_Y = 30*mm  # footer clearance — aggiornato dinamicamente dopo prima pagina

    def new_page(self):
        if self.page_num > 0:
            self.c.showPage()
        self.page_num += 1
        draw_header(self.c, self.d, self.page_num, self.total_pages)
        draw_footer(self.c, self.page_num, self.total_pages,
                    footer_notes=self.d.get('footer_notes'),
                    has_all1=self.d.get('has_all1', True),
                    has_all2=self.d.get('has_all2', True))
        # Aggiorna MIN_Y in base all'altezza reale del footer appena disegnato
        fh = getattr(draw_footer, '_last_h', 22*mm)
        self.MIN_Y = fh + 8*mm
        # Header height è 31mm (includes the green bar at top)
        HEADER_H = 31*mm
        self.y = H - HEADER_H - 2*mm

    def need_space(self, h):
        return self.y - h < self.MIN_Y

    def ensure(self, h):
        if self.need_space(h):
            self.new_page()

    def clamp_y(self):
        """Force new page if pb.y has drifted below the safe minimum."""
        if self.y < self.MIN_Y:
            self.new_page()

    def gap(self, h=4*mm):
        self.y -= h
        self.clamp_y()

    def section(self, title, icon, bg, kcal_txt=None, prot_txt=None):
        self.ensure(10*mm)
        sec_bar(self.c, self.M, self.y, title, icon, bg, self.CW, kcal_txt, prot_txt)
        self.y -= 10*mm

    def info_bar(self, line1_label, line1_val, line2_label, line2_val, bg, label_color):
        """Due colonne parallele: Verdure | Condimento - FIX SOVRAPPOSIZIONE v18"""
        # Font sizes
        FONT_SZ_LABEL = 8
        FONT_SZ_VAL = 7.2
        LH = 4.5*mm  # Line height per il wrapping del testo
        
        # Funzione per contare le righe di testo wrappato
        def count_wrapped_lines(text, max_width):
            """Calcola il numero di righe necessarie per il wrapping."""
            if not text:
                return 1
            self.c.setFont("Helvetica", FONT_SZ_VAL)
            words = text.split()
            lines = 1
            line = ''
            for w in words:
                test = (line + ' ' + w).strip() if line else w
                if self.c.stringWidth(test, "Helvetica", FONT_SZ_VAL) > max_width and line:
                    lines += 1
                    line = w
                else:
                    line = test
            return lines
        
        # Layout: due colonne (Verdure | Condimento)
        col_w = (self.CW - 6*mm) / 2  # Larghezza colonna
        
        # Stima righe per ogni colonna
        line1_lines = count_wrapped_lines(line1_val, col_w - 5*mm)
        line2_lines = count_wrapped_lines(line2_val, col_w - 5*mm)
        max_lines = max(line1_lines, line2_lines)
        
        # Altezza: etichetta + spazio + righe testo
        # 6mm per label + spazio, poi max_lines * LH per il testo
        h = 6*mm + max_lines * LH + 3*mm
        h = max(20*mm, h)  # Minimo 20mm per evitare troppo compattamento
        
        self.ensure(h + 2*mm)
        rrect(self.c, self.M, self.y-h+1*mm, self.CW, h, r=3*mm, fill=bg)
        
        # COLONNA 1: Verdure (sinistra)
        col1_x = self.M + 3*mm
        # Etichetta sulla prima riga
        self.c.setFillColor(label_color)
        self.c.setFont("Helvetica-Bold", FONT_SZ_LABEL)
        self.c.drawString(col1_x, self.y - 4*mm, line1_label)
        
        # Testo colonna 1 con wrapping - inizia SOTTO l'etichetta
        val1_y = self.y - 4*mm - 5*mm  # 5mm sotto l'etichetta
        draw_wrapped(self.c, col1_x, val1_y, line1_val, "Helvetica", FONT_SZ_VAL,
                     col_w - 5*mm, LH, DARK, indent=0)
        
        # COLONNA 2: Condimento (destra)
        col2_x = self.M + col_w + 3*mm
        # Etichetta sulla prima riga
        self.c.setFillColor(ORANGE)
        self.c.setFont("Helvetica-Bold", FONT_SZ_LABEL)
        self.c.drawString(col2_x, self.y - 4*mm, line2_label)
        
        # Testo colonna 2 con wrapping - inizia SOTTO l'etichetta
        val2_y = self.y - 4*mm - 5*mm  # 5mm sotto l'etichetta
        draw_wrapped(self.c, col2_x, val2_y, line2_val, "Helvetica", FONT_SZ_VAL,
                     col_w - 5*mm, LH, DARK, indent=0)
        
        self.y -= h + 2*mm

    def instruction_line(self, text):
        self.ensure(8*mm)
        self.c.setFillColor(DARK); self.c.setFont("Helvetica-BoldOblique", 7.5)
        self.c.drawString(self.M, self.y-1*mm, text)
        self.y -= 6*mm

    def note_line(self, text):
        self.ensure(5*mm)
        self.c.setFillColor(GRAY_TEXT); self.c.setFont("Helvetica-Oblique", 6)
        self.c.drawString(self.M, self.y-2*mm, text[:120])
        self.y -= 5*mm


# ─────────────────────────────────────────────────────────────────────────────
# MAIN BUILD FUNCTION
# ─────────────────────────────────────────────────────────────────────────────
VERDURE_NOTE = ("\u2265 200 g verdure *evitare: melanzane, peperoni, pomodori, peperoncini e patate"
                "  \u2022  1 frutto a scelta* (no tropicale)")
CONDIMENTO   = "1 cucchiaio olio evo/cocco  \u2022  2 cucchiai pesto  \u2022  110 ml salsa di soia  \u2022  100 ml aceto balsamico"
NOTE_FOOTER  = ("\u26a0  Prediligere sempre prodotti senza glutine (Kamut/Senatore Cappelli/Grani Antichi) e senza lattosio")


def count_pages(d):
    """Rough page count estimate."""
    pages = 1
    sections = sum([
        d.get('colazione_presente', False),
        d.get('spuntino_mattina_presente', False),
        d.get('pranzo_presente', False),
        d.get('spuntino_pomeriggio_presente', False),
        d.get('cena_presente', False),
    ])
    if sections > 3:
        pages += 1
    # Dedicated page for esempi + mix
    has_esempi = bool(d.get('pranzo_esempi') or d.get('cena_esempi'))
    has_mix    = bool(d.get('pranzo_mix') or d.get('cena_mix'))
    if has_esempi or has_mix:
        pages += 1
    if d.get('pasto_fuori_presente') or d.get('integrazione_presente'):
        pages += 1
    return max(pages, 2)


def build_pdf(d, output_path):
    total_pages = count_pages(d)
    cv_obj = canvas.Canvas(output_path, pagesize=A4)
    pb = PageBuilder(cv_obj, d, total_pages)
    pb.new_page()
    M = pb.M; CW = pb.CW; c = pb.c

    # ── COLAZIONE ────────────────────────────────────────────────────────────
    if d.get('colazione_presente'):
        # Usa header dinamico da J4
        col_header = d.get('colazione_header', 'COLAZIONE')
        pb.section(col_header, "\U0001f305", GREEN_DARK,
                   kcal_txt=d['colazione_kcal'], prot_txt=d['colazione_prot'])

        # ── Intro: tutto nello stesso riquadro verde ─────────────────────────
        intro_base  = d.get('colazione_base', '')
        intro2      = d.get('colazione_intro2', '')
        nota_blu    = d.get('colazione_nota_blu', '')
        opts = d.get('colazione_opzioni', [])

        # NON aggiungere testo automatico - viene letto dall'Excel
        # Il testo "a cui aggiungere..." deve essere già presente in intro_base dall'Excel

        if intro_base:
            # intro_base include gia' "a cui aggiungere..." — conta le righe di wrap
            LINE_H_INTRO = 4.5*mm
            c.setFont("Helvetica-BoldOblique", 7)

            def _count_wrap_lines(text, font, sz, max_w):
                words = text.split(); lines = 1; line = ''
                for w in words:
                    test = (line + ' ' + w).strip()
                    if c.stringWidth(test, font, sz) > max_w and line:
                        lines += 1; line = w
                    else:
                        line = test
                return lines

            n_lines = _count_wrap_lines(intro_base, "Helvetica-BoldOblique", 7, CW - 6*mm)
            # nota_blu su riga extra sotto il testo
            extra_row = 1 if nota_blu else 0
            INTRO_H = max(8*mm, (n_lines + extra_row) * LINE_H_INTRO + 3*mm)
            pb.ensure(INTRO_H + 2*mm)
            rrect(c, M, pb.y - INTRO_H, CW, INTRO_H, r=2*mm,
                  fill=GREEN_BG, stroke=GREEN_DARK, sw=0.4)

            # Testo principale (wrap)
            iy = pb.y - 3*mm
            iy = draw_wrapped(c, M + 3*mm, iy, intro_base,
                              "Helvetica-BoldOblique", 7,
                              CW - 6*mm, LINE_H_INTRO, GREEN_DARK, indent=5*mm)

            # Nota blu sulla riga successiva, allineata a destra
            if nota_blu:
                iy -= 0.5*mm
                c.setFillColor(colors.HexColor("#0070C0"))
                c.setFont("Helvetica-Oblique", 6)
                c.drawRightString(M + CW - 3*mm, iy, nota_blu)

            pb.y -= INTRO_H + 2*mm

        opts = d.get('colazione_opzioni', [])

        # Se c'è solo una opzione, mostrarla inline (come gli spuntini)
        # sotto l'intro, senza card con header verde
        if len(opts) == 1:
            opt_single = opts[0]
            # Raccoglie tutti gli item dell'unica opzione
            all_items = opt_single['items']
            # header_item (es. "250 g / 300 g all. Latte parzi...") → riga intro extra
            header_item = None
            bullet_items = []
            for it in all_items:
                if isinstance(it, str) and it.startswith('__HDR__ '):
                    header_item = it[len('__HDR__ '):]
                else:
                    bullet_items.append(it)

            LINE_H_OPZ = 5.5*mm
            FONT_SZ_OPZ = 7
            # Calcola altezza box inline
            n_lines = (1 if header_item else 0) + len(bullet_items)
            INLINE_H = max(10*mm, n_lines * LINE_H_OPZ + 6*mm)
            pb.ensure(INLINE_H + 2*mm)
            rrect(c, M, pb.y - INLINE_H, CW, INLINE_H + 1*mm, r=2*mm,
                  fill=GREEN_BG, stroke=GREEN_DARK, sw=0.4)
            oy = pb.y - 4*mm

            if header_item:
                c.setFillColor(GREEN_DARK); c.setFont("Helvetica-Bold", FONT_SZ_OPZ)
                oy = draw_wrapped(c, M + 3*mm, oy, header_item,
                                  "Helvetica-Bold", FONT_SZ_OPZ,
                                  CW - 6*mm, LINE_H_OPZ, GREEN_DARK, indent=3*mm)

            for item in bullet_items:
                c.setFillColor(GREEN); c.circle(M + 4*mm, oy + 1.3*mm, 0.8*mm, fill=1, stroke=0)
                if isinstance(item, dict):
                    tx = M + 7*mm
                    if item['segs']:
                        tx = draw_segments(c, tx, oy, item['segs'], FONT_SZ_OPZ, DARK, COL_ITALIC, COL_BOLD)
                    c.setFont("Helvetica", FONT_SZ_OPZ); c.setFillColor(DARK)
                    avail_w = M + CW - tx - 2*mm
                    oy = draw_wrapped(c, tx + 0.5*mm, oy, item['name'], "Helvetica", FONT_SZ_OPZ,
                                      avail_w, LINE_H_OPZ, DARK, indent=2*mm)
                else:
                    c.setFillColor(DARK)
                    oy = draw_wrapped(c, M + 7*mm, oy, str(item), "Helvetica", FONT_SZ_OPZ,
                                      CW - 9*mm, LINE_H_OPZ, DARK, indent=2*mm)

            pb.y -= INLINE_H + 4*mm

        elif len(opts) > 1:
            # Più opzioni: rinumerare progressivamente e mostrare come cards
            for i, opt in enumerate(opts, 1):
                opt['titolo'] = f"OPZIONE {i}"

        GAP = 3*mm
        FONT_SZ_ITEM = 6.3
        LH_ITEM      = 5.5*mm   # v18: Aumentato da 4.3mm a 5.5mm per più spazio tra righe
        LH_HEADER    = 4.5*mm   # v18: Aumentato da 3.8mm a 4.5mm
        CARD_TOP_PAD = 12*mm    # space from card top to first item (header bar + gap)
        CARD_BOT_PAD = 3*mm

        def _opt_card_height(opt, card_w):
            """Compute exact card height needed for all items."""
            h = CARD_TOP_PAD + CARD_BOT_PAD
            for item in opt['items']:
                if isinstance(item, str) and item.startswith('__HDR__ '):
                    clean = item[len('__HDR__ '):]
                    # estimate wrap lines
                    words = clean.split(); line = ''; lines = 1
                    c.setFont("Helvetica-Bold", 6.5)
                    for w in words:
                        test = (line + ' ' + w).strip()
                        if c.stringWidth(test, "Helvetica-Bold", 6.5) > card_w - 5*mm and line:
                            lines += 1; line = w
                        else:
                            line = test
                    h += lines * LH_HEADER + 1*mm
                elif isinstance(item, dict):
                    # segs on one line, then name wraps
                    segs_w = sum(c.stringWidth(t, {
                        'italic': 'Helvetica-Oblique', 'bold': 'Helvetica-Bold'
                    }.get(s, 'Helvetica'), FONT_SZ_ITEM) for t, s in item['segs'])
                    tx_start = 6.5*mm + segs_w + c.stringWidth("  ", "Helvetica", FONT_SZ_ITEM)
                    name_w = card_w - tx_start - 1*mm
                    words = item['name'].split(); line = ''; lines = 1
                    c.setFont("Helvetica", FONT_SZ_ITEM)
                    for w in words:
                        test = (line + ' ' + w).strip()
                        if c.stringWidth(test, "Helvetica", FONT_SZ_ITEM) > max(name_w, 10*mm) and line:
                            lines += 1; line = w
                        else:
                            line = test
                    h += lines * LH_ITEM
                else:
                    h += LH_ITEM
            return h

        if len(opts) <= 1:
            # Already handled above (inline or no options) — nothing more to draw
            pass
        else:
            opt1   = [o for o in opts if '1' in o.get('titolo', '')]
            others = [o for o in opts if '1' not in o.get('titolo', '')]

            # Compute dynamic height based on content
            if opt1:
                OPT_H_TALL = _opt_card_height(opt1[0], CW)
            else:
                OPT_H_TALL = 28*mm
            
            # For other options, compute height dynamically
            OPT_H_SHORT = 28*mm
            if others and len(others) > 0:
                max_h = 0
                for o in others[:2]:
                    ow = (CW - GAP) / 2
                    h = _opt_card_height(o, ow)
                    max_h = max(max_h, h)
                if max_h > 0:
                    OPT_H_SHORT = max(28*mm, max_h)

            rows_of_opts = []
            if opt1:   rows_of_opts.append((opt1, OPT_H_TALL))
            if others:
                if len(others) <= 2:
                    rows_of_opts.append((others, OPT_H_SHORT))
                else:
                    rows_of_opts.append((others[:2], OPT_H_SHORT))
                if len(others) > 2:
                    max_h = 0
                    for o in others[2:4]:
                        ow = (CW - GAP) / 2
                        h = _opt_card_height(o, ow)
                        max_h = max(max_h, h)
                    rows_of_opts.append((others[2:4], max(28*mm, max_h)))

            TOTAL_H = sum(h + GAP for _, h in rows_of_opts) + 2*mm
            pb.ensure(TOTAL_H + 2*mm)
            row_y = pb.y

            for row_opts, OPT_H in rows_of_opts:
                n  = len(row_opts)
                ow = (CW - (n - 1) * GAP) / n
                for i, opt in enumerate(row_opts):
                    x0 = M + i * (ow + GAP)
                    y0 = row_y - OPT_H
                    rrect(c, x0, y0, ow, OPT_H, r=2*mm, fill=WHITE, stroke=GREEN, sw=0.5)
                    rrect(c, x0, row_y - 7.5*mm, ow, 7.5*mm, r=2*mm, fill=GREEN_DARK)
                    c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 7)
                    c.drawCentredString(x0 + ow/2, row_y - 5*mm, opt['titolo'])
                    oy = row_y - 12*mm
                    for item in opt['items']:
                        if isinstance(item, str) and item.startswith('__HDR__ '):
                            clean = item[len('__HDR__ '):]
                            c.setFillColor(GREEN_DARK); c.setFont("Helvetica-Bold", 6.5)
                            oy = draw_wrapped(c, x0+3*mm, oy, clean, "Helvetica-Bold", 6.5,
                                              ow-5*mm, LH_HEADER, GREEN_DARK, indent=2*mm)
                            oy -= 1*mm
                        elif isinstance(item, dict):
                            c.setFillColor(GREEN)
                            c.circle(x0+3.5*mm, oy+1.5*mm, 0.8*mm, fill=1, stroke=0)
                            tx = x0+6.5*mm
                            if item['segs']:
                                tx = draw_segments(c, tx, oy, item['segs'], FONT_SZ_ITEM, DARK, COL_ITALIC, COL_BOLD)
                            if item.get('name'):
                                c.setFont("Helvetica", FONT_SZ_ITEM); c.setFillColor(DARK)
                                c.drawString(tx, oy, "  ")
                                tx += c.stringWidth("  ", "Helvetica", FONT_SZ_ITEM)
                                name_w = ow - (tx - x0) - 1*mm
                                oy = draw_wrapped(c, tx, oy, item['name'], "Helvetica", FONT_SZ_ITEM,
                                                  name_w, LH_ITEM, DARK, indent=2*mm)
                            else:
                                oy -= LH_ITEM
                        else:
                            c.setFillColor(GREEN)
                            c.circle(x0+3.5*mm, oy+1.5*mm, 0.8*mm, fill=1, stroke=0)
                            oy = draw_wrapped(c, x0+6.5*mm, oy, str(item), "Helvetica", FONT_SZ_ITEM,
                                              ow-8*mm, LH_ITEM, DARK, indent=2*mm)

                row_y -= OPT_H + GAP

            pb.y = row_y - 4*mm


    def _draw_spuntino_box(label, opz, intro_text, kcal_txt, prot_txt, dot_color, bg_color, stroke_color):
        """Render a spuntino section with colazione-style spacing. Handles wrap-aware height."""
        FONT_SZ   = 7
        LH        = 5.5*mm    # line height per bullet
        LH_SUB    = 5.0*mm    # line height per sub-option
        PAD_TOP   = 4*mm
        PAD_BOT   = 4*mm
        INTRO_LH  = 5*mm

        def _wrap_lines(text, font, sz, max_w):
            words = text.split(); lines = 1; line = ''
            for w in words:
                test = (line + ' ' + w).strip()
                if c.stringWidth(test, font, sz) > max_w and line:
                    lines += 1; line = w
                else:
                    line = test
            return lines

        # ── Measure height ────────────────────────────────────────────────────
        avail_text_w = CW - 9*mm   # bullet(4.5) + margin
        SP_H = PAD_TOP + PAD_BOT
        if intro_text:
            SP_H += INTRO_LH
        for item in opz:
            name = item['name'] if isinstance(item, dict) else str(item)
            if '   ->  ' in name:
                main_part, sub_part = name.split('   ->  ', 1)
                sub_opts = [s.strip() for s in sub_part.split('  |  ')]
                n = _wrap_lines(main_part, 'Helvetica', FONT_SZ, avail_text_w)
                SP_H += n * LH + 1.5*mm  # gap before sub-options
                for sub in sub_opts:
                    ns = _wrap_lines(sub, 'Helvetica', FONT_SZ - 0.5, avail_text_w - 3*mm)
                    SP_H += ns * LH_SUB
            else:
                n = _wrap_lines(name, 'Helvetica', FONT_SZ, avail_text_w)
                SP_H += n * LH
        SP_H = max(14*mm, SP_H)

        # ── Draw ─────────────────────────────────────────────────────────────
        pb.gap(4*mm)
        pb.ensure(10*mm + SP_H + 2*mm)
        sec_bar(c, M, pb.y, label, "\U0001f34e", stroke_color, CW,
                kcal_txt=kcal_txt, prot_txt=prot_txt)
        pb.y -= 10*mm

        rrect(c, M, pb.y - SP_H, CW, SP_H + 1*mm, r=3*mm,
              fill=bg_color, stroke=stroke_color, sw=0.4)
        oy = pb.y - PAD_TOP

        if intro_text:
            c.setFillColor(stroke_color); c.setFont("Helvetica-BoldOblique", 6.8)
            c.drawString(M + 4*mm, oy, intro_text)
            oy -= INTRO_LH

        for item in opz:
            name = item['name'] if isinstance(item, dict) else str(item)
            segs = item['segs'] if isinstance(item, dict) else []

            if '   ->  ' in name:
                main_part, sub_part = name.split('   ->  ', 1)
                sub_opts = [s.strip() for s in sub_part.split('  |  ')]
            else:
                main_part = name
                sub_opts = []

            # Bullet
            c.setFillColor(dot_color)
            c.circle(M + 4*mm, oy + 1.3*mm, 0.8*mm, fill=1, stroke=0)
            tx = M + 7*mm
            if segs:
                tx = draw_segments(c, tx, oy, segs, FONT_SZ, DARK, COL_ITALIC, COL_BOLD)
                c.setFont("Helvetica", FONT_SZ); c.setFillColor(DARK)
                c.drawString(tx, oy, "  ")
                tx += c.stringWidth("  ", "Helvetica", FONT_SZ)
            avail_w = M + CW - tx - 2*mm
            oy = draw_wrapped(c, tx, oy, main_part, "Helvetica", FONT_SZ,
                              avail_w, LH, DARK, indent=2*mm)

            # Sub-options
            if sub_opts:
                oy -= 1.5*mm
                for sub in sub_opts:
                    c.setFillColor(DARK); c.setFont("Helvetica", FONT_SZ - 0.5)
                    oy = draw_wrapped(c, M + 9*mm, oy, sub, "Helvetica", FONT_SZ - 0.5,
                                      CW - 11*mm, LH_SUB, DARK, indent=3*mm)

        pb.y -= SP_H + 4*mm



    # ── SPUNTINO MATTINA ─────────────────────────────────────────────────────
    if d.get('spuntino_mattina_presente'):
        _draw_spuntino_box(
            label      = d.get('spuntino_mattina_title', '') or "SPUNTINO MATTINA",
            opz        = d.get('spuntino_mattina_opzioni', []),
            intro_text = d.get('spuntino_mattina_intro', ''),
            kcal_txt   = d['spuntino_mattina_kcal'],
            prot_txt   = d['spuntino_mattina_prot'],
            dot_color  = TEAL,
            bg_color   = TEAL_BG,
            stroke_color = TEAL,
        )

    # ── PRANZO ───────────────────────────────────────────────────────────────
    if d.get('pranzo_presente'):
        pb.ensure(150*mm)  # Aumentato a 150mm per evitare sovrapposizioni
        pb.section(d.get('pranzo_header', 'PRANZO'), "\u2600\ufe0f", GREEN_DARK,
                   kcal_txt=d['pranzo_kcal'], prot_txt=d['pranzo_prot'])
        _vn = d.get("pranzo_verdure") or VERDURE_NOTE
        _co = d.get("pranzo_condimento") or CONDIMENTO
        pb.info_bar("\U0001f957 Verdure e frutto:", _vn, "\U0001fad2 Condimento:", _co, GREEN_BG, GREEN_DARK)
        # Usa testo dinamico da A62
        pranzo_istr = d.get("pranzo_istruzione", "Abbina poi un'opzione di carboidrati ad un'opzione proteica fra quelle proposte di seguito:")
        pb.instruction_line(pranzo_istr)
        new_y = draw_protein_table(c, M, pb.y, CW, d['pranzo_prot_cols'], d['pranzo_carbo'], pb=pb)
        pb.y = new_y
        pb.gap(8*mm)  # Gap aumentato prima della prossima sezione

    # ── SPUNTINO POMERIGGIO ───────────────────────────────────────────────────
    if d.get('spuntino_pomeriggio_presente'):
        _draw_spuntino_box(
            label      = d.get('spuntino_pomeriggio_title', '') or "SPUNTINO POMERIGGIO",
            opz        = d.get('spuntino_pomeriggio_opzioni', []),
            intro_text = d.get('spuntino_pomeriggio_intro', ''),
            kcal_txt   = d['spuntino_pomeriggio_kcal'],
            prot_txt   = d['spuntino_pomeriggio_prot'],
            dot_color  = TEAL,
            bg_color   = TEAL_BG,
            stroke_color = TEAL,
        )

    # ── CENA ─────────────────────────────────────────────────────────────────
    if d.get('cena_presente'):
        pb.ensure(150*mm)  # Aumentato a 150mm
        pb.section(d.get('cena_header', 'CENA'), "\U0001f319", ACCENT,
                   kcal_txt=d['cena_kcal'], prot_txt=d['cena_prot'])
        _vn = d.get("cena_verdure") or VERDURE_NOTE
        _co = d.get("cena_condimento") or CONDIMENTO
        pb.info_bar("\U0001f957 Verdure e frutto:", _vn, "\U0001fad2 Condimento:", _co, BLUE_BG, colors.HexColor("#1A5276"))
        # Usa testo dinamico da A137
        cena_istr = d.get("cena_istruzione", "Abbina un'opzione di carboidrati ad un'opzione proteica fra quelle proposte di seguito:")
        pb.instruction_line(cena_istr)
        new_y = draw_protein_table(c, M, pb.y, CW, d['cena_prot_cols'], d['cena_carbo'], pb=pb)
        pb.y = new_y
        pb.gap(8*mm)  # Gap aumentato

    # ── PAGINA DEDICATA: ESEMPI SETTIMANALI + MIX PROTEICI ───────────────────
    all_esempi = d.get('pranzo_esempi', []) + d.get('cena_esempi', [])
    mix_pranzo = [m for m in d.get('pranzo_mix', []) if m]
    mix_cena   = [m for m in d.get('cena_mix',   []) if m]

    # Determina se i mix sono identici → una tabella sola, altrimenti due separate
    mix_identici = (mix_pranzo == mix_cena)
    mix_all = list(mix_pranzo) if mix_identici else []

    if all_esempi or mix_pranzo or mix_cena:
        pb.new_page()

        # ── Esempi settimanali ────────────────────────────────────────────────
        if all_esempi:
            pb.section("ESEMPI SETTIMANALI", "\U0001f4c5", ACCENT)
            if d.get('pranzo_esempi'):
                c.setFillColor(GREEN_DARK); c.setFont("Helvetica-Bold", 8)
                c.drawString(M, pb.y - 2*mm, "\U0001f315  PRANZO")
                pb.y -= 6*mm
                new_y = draw_esempi_table(c, M, pb.y, CW, d['pranzo_esempi'], GREEN_DARK, GREEN_BG)
                pb.y = new_y
            if d.get('cena_esempi'):
                pb.ensure(38*mm)
                c.setFillColor(BLUE); c.setFont("Helvetica-Bold", 8)
                c.drawString(M, pb.y - 2*mm, "\U0001f319  CENA")
                pb.y -= 6*mm
                new_y = draw_esempi_table(c, M, pb.y, CW, d['cena_esempi'], BLUE, BLUE_BG)
                pb.y = new_y
            pb.gap(4*mm)

        # ── Mix proteici ──────────────────────────────────────────────────────
        def _draw_mix_box(pb, items, title, color, bg):
            if not items: return
            MIX_LINE_H = 5.5*mm
            MIX_H = len(items) * MIX_LINE_H + 6*mm
            # Ensure header (10mm) + box on same page
            pb.gap(4*mm)
            pb.ensure(10*mm + MIX_H + 4*mm)
            sec_bar(c, M, pb.y, title, "\U0001f500", color, CW)
            pb.y -= 10*mm
            rrect(c, M, pb.y - MIX_H, CW, MIX_H + 1*mm, r=3*mm, fill=bg, stroke=color, sw=0.3)
            my = pb.y - 4.5*mm
            for item in items:
                c.setFillColor(color); c.circle(M + 3.5*mm, my + 1.3*mm, 0.9*mm, fill=1, stroke=0)
                if isinstance(item, dict):
                    tx = M + 7*mm
                    if item['segs']:
                        tx = draw_segments(c, tx, my, item['segs'], 7.2, DARK, COL_ITALIC, COL_BOLD)
                    name_w = CW - (tx - M) - 2*mm
                    my = draw_wrapped(c, tx+0.5*mm, my, item['name'], "Helvetica", 7.2,
                                      name_w, MIX_LINE_H, DARK, indent=3*mm)
                else:
                    my = draw_wrapped(c, M+7*mm, my, str(item), "Helvetica", 7.2,
                                      CW-10*mm, MIX_LINE_H, DARK, indent=3*mm)
            pb.y -= MIX_H + 4*mm

        if mix_identici and mix_all:
            # Unica tabella mix (pranzo e cena identici)
            _draw_mix_box(pb, mix_all, "ESEMPI DI MIX PROTEICI:", PURPLE, PURPLE_BG)
        else:
            # Due tabelle separate - Usa header dinamico da Excel SOLO
            if mix_pranzo:
                pranzo_mix_title = d.get('pranzo_mix_header', 'Mix Proteici')
                _draw_mix_box(pb, mix_pranzo, pranzo_mix_title, GREEN_DARK, GREEN_BG)
            if mix_cena:
                cena_mix_title = d.get('cena_mix_header', 'Mix Proteici')
                _draw_mix_box(pb, mix_cena, cena_mix_title, BLUE, BLUE_BG)


    # ── INTEGRAZIONE ──────────────────────────────────────────────────────────
    if d.get('integrazione_presente'):
        integ = d['integrazione']
        INT_H = len(integ)*12*mm + 4*mm
        pb.ensure(INT_H + 12*mm)
        pb.gap(4*mm)
        pb.section("INTEGRAZIONE", "\U0001f48a", RED)
        rrect(c, M, pb.y-INT_H, CW, INT_H+1*mm, r=3*mm,
              fill=colors.HexColor("#FDEDEC"), stroke=RED, sw=0.3)
        iy = pb.y - 4*mm
        for item in integ:
            c.setFillColor(RED); c.circle(M+3*mm, iy+0.5*mm, 0.9*mm, fill=1, stroke=0)
            iy = draw_wrapped(c, M+7*mm, iy, str(item), "Helvetica", 8,
                              CW-8*mm, 5*mm, DARK, indent=3*mm)
            iy -= 3*mm
        pb.y -= INT_H + 4*mm

    # ── PASTO FUORI ───────────────────────────────────────────────────────────
    if d.get('pasto_fuori_presente'):
        FONT_SZ = 7.5; LINE_H = 5.5*mm; PILL_H = 7*mm
        rows_data = d['pasto_fuori_rows']

        def wrap(text, max_w):
            mc = int(max_w/(FONT_SZ*0.52)); words = text.split(); line=""; out=[]
            for w in words:
                test=(line+" "+w).strip()
                if len(test)<=mc: line=test
                else: out.append(line); line=w
            if line: out.append(line)
            return out

        pf_rows_computed = []
        # Usa max_pw per TUTTE le pill → stessa larghezza
        max_pw = max(c.stringWidth(lbl, "Helvetica-Bold", 7.5) + 10*mm
                     for lbl, _, _ in rows_data) if rows_data else 20*mm
        PILL_W = max_pw
        TEXT_X = M + 4*mm + PILL_W + 4*mm   # x fissa per tutti i testi
        TEXT_W = CW - (TEXT_X - M) - 4*mm

        for lbl, text, col in rows_data:
            lines = []
            words = text.split(); cur = ''
            for w in words:
                test = (cur + ' ' + w).strip()
                if c.stringWidth(test, "Helvetica", FONT_SZ) <= TEXT_W: cur = test
                else:
                    if cur: lines.append(cur)
                    cur = w
            if cur: lines.append(cur)
            if not lines: lines = [text]
            row_h = max(PILL_H + 4*mm, len(lines) * LINE_H + 4*mm)
            pf_rows_computed.append((lbl, col, PILL_W, TEXT_X, lines, row_h))

        locali = d.get('pasto_fuori_locali', [])
        PF_H = sum(r[5] for r in pf_rows_computed) + 3*mm*len(pf_rows_computed) + \
               (6*mm + len(locali)*5.5*mm + 4*mm if locali else 0) + 6*mm
        pb.ensure(PF_H + 12*mm)
        pb.gap(4*mm)
        pb.section("PASTO FUORI", "\U0001f37d\ufe0f", ORANGE)
        rrect(c, M, pb.y-PF_H, CW, PF_H+1*mm, r=3*mm, fill=ORANGE_BG, stroke=ORANGE, sw=0.3)
        iy2 = pb.y - 4*mm
        for lbl, col, pw, tx, lines, row_h in pf_rows_computed:
            text_block_h = len(lines) * LINE_H
            ty_first = iy2 - (row_h - text_block_h) / 2
            # Top della pill = top del testo (baseline + cap-height ≈ font*0.72)
            pill_y = ty_first - PILL_H + 7.5 * 0.72 * mm
            pill(c, M+4*mm, pill_y, pw, PILL_H, col)
            c.setFillColor(WHITE); c.setFont("Helvetica-Bold", 7.5)
            c.drawCentredString(M+4*mm + pw/2, pill_y + PILL_H * 0.32, lbl)
            ty = ty_first
            for ln in lines:
                c.setFillColor(DARK); c.setFont("Helvetica", FONT_SZ)
                c.drawString(tx, ty, ln); ty -= LINE_H
            iy2 -= row_h + 3*mm
        if locali:
            iy2 -= 2*mm
            for loc in locali:
                c.setFillColor(ORANGE); c.circle(M+5*mm, iy2+1.5*mm, 0.9*mm, fill=1, stroke=0)
                c.setFillColor(DARK); c.setFont("Helvetica", 8)
                c.drawString(M+8.5*mm, iy2, loc); iy2 -= 5.5*mm
        pb.y -= PF_H + 4*mm

    # ── SEZIONI EXTRA (max 3, stile integrazione, tutto viola) ───────────────
    extra_sections = d.get('extra_sections', [])
    ESEC_COLOR = PURPLE
    ESEC_BG    = PURPLE_BG
    ESEC_FONT  = 8
    ESEC_LH    = 5*mm
    ESEC_GAP   = 3*mm

    # Larghezza testo disponibile nelle celle viola:
    ESEC_TEXT_X  = M + 7*mm
    ESEC_MAX_W   = CW - 14*mm

    def _rich_line_width(line_segs):
        """Calcola la larghezza di una riga di segmenti rich-text."""
        w = 0
        for seg in line_segs:
            text = seg['text']
            if seg['bold'] and seg['italic']:
                fn = "Helvetica-BoldOblique"
            elif seg['bold']:
                fn = "Helvetica-Bold"
            elif seg['italic']:
                fn = "Helvetica-Oblique"
            else:
                fn = "Helvetica"
            w += c.stringWidth(text, fn, ESEC_FONT)
        return w

    def _draw_rich_line(line_segs, x, y):
        """Disegna una riga di segmenti rich-text alla posizione (x, y). Ritorna x finale."""
        for seg in line_segs:
            text = seg['text']
            if seg['bold'] and seg['italic']:
                fn = "Helvetica-BoldOblique"
            elif seg['bold']:
                fn = "Helvetica-Bold"
            elif seg['italic']:
                fn = "Helvetica-Oblique"
            else:
                fn = "Helvetica"
            c.setFont(fn, ESEC_FONT)
            c.setFillColor(DARK)
            if seg.get('underline'):
                # Disegna il testo e poi una linea sotto
                c.drawString(x, y, text)
                tw = c.stringWidth(text, fn, ESEC_FONT)
                c.setLineWidth(0.4)
                c.setStrokeColor(DARK)
                c.line(x, y - 1, x + tw, y - 1)
                x += tw
            else:
                c.drawString(x, y, text)
                x += c.stringWidth(text, fn, ESEC_FONT)
        return x

    def _split_rich_into_visual_lines(segs_list):
        """
        Prende una lista di segmenti rich-text (da una singola cella Excel),
        spezza sugli \\n espliciti e poi fa word-wrap per ogni riga.
        Restituisce una lista di 'righe visive', ognuna è una lista di segmenti.
        """
        # Prima: espandi i \\n all'interno di ogni segmento
        flat_parts = []  # lista di (text_piece, bold, italic, underline)
        for seg in segs_list:
            text = seg['text']
            bold = seg['bold']; italic = seg['italic']; underline = seg.get('underline', False)
            # Splitta su \\n mantenendo i marcatori di riga
            pieces = text.split('\n')
            for i, piece in enumerate(pieces):
                if piece:
                    flat_parts.append({'text': piece, 'bold': bold, 'italic': italic,
                                       'underline': underline, 'newline_after': False})
                if i < len(pieces) - 1:
                    # C'era un \\n: forza a capo
                    if flat_parts:
                        flat_parts[-1] = dict(flat_parts[-1], newline_after=True)
                    else:
                        # \\n all'inizio: inserisci un pezzo vuoto con newline
                        flat_parts.append({'text': '', 'bold': bold, 'italic': italic,
                                           'underline': underline, 'newline_after': True})

        # Ora fai word-wrap: accumula parole per riga
        visual_lines = []
        current_line = []  # lista di seg dict per la riga corrente
        current_w = 0

        def _seg_word_width(word, bold, italic):
            if bold and italic: fn = "Helvetica-BoldOblique"
            elif bold:          fn = "Helvetica-Bold"
            elif italic:        fn = "Helvetica-Oblique"
            else:               fn = "Helvetica"
            return c.stringWidth(word, fn, ESEC_FONT)

        def flush_line():
            nonlocal current_line, current_w
            visual_lines.append(current_line)
            current_line = []
            current_w = 0

        for part in flat_parts:
            raw_text = part['text']
            bold = part['bold']; italic = part['italic']; underline = part.get('underline', False)
            force_break_after = part['newline_after']

            if not raw_text and force_break_after:
                flush_line()
                continue

            # Splitta in parole mantenendo spazi
            words = raw_text.split(' ')
            first_word_in_part = True
            for wi, word in enumerate(words):
                if not word:
                    # spazio: aggiunge un piccolo spazio all'ultimo segmento se la riga non è vuota
                    if current_line:
                        # aggiungi spazio al segmento precedente se ha lo stesso stile,
                        # altrimenti crea un segmento spazio
                        space_w = _seg_word_width(' ', bold, italic)
                        if current_w + space_w <= ESEC_MAX_W:
                            # appendi uno spazio
                            if current_line and current_line[-1]['bold'] == bold and \
                               current_line[-1]['italic'] == italic:
                                current_line[-1] = dict(current_line[-1],
                                                        text=current_line[-1]['text'] + ' ')
                            else:
                                current_line.append({'text': ' ', 'bold': bold,
                                                     'italic': italic, 'underline': underline})
                            current_w += space_w
                    continue

                # Prepend spazio se non è il primo token della riga corrente e non è il primo nel part
                prefix = ' ' if (current_line and not first_word_in_part) else (
                         ' ' if (current_line and first_word_in_part) else '')
                display = prefix + word
                ww = _seg_word_width(display, bold, italic)

                if current_w + ww > ESEC_MAX_W and current_line:
                    flush_line()
                    display = word  # niente spazio a inizio riga nuova
                    ww = _seg_word_width(display, bold, italic)

                # Unisci con l'ultimo segmento se stesso stile
                if current_line and current_line[-1]['bold'] == bold and \
                   current_line[-1]['italic'] == italic and \
                   current_line[-1].get('underline', False) == underline:
                    current_line[-1] = dict(current_line[-1],
                                            text=current_line[-1]['text'] + display)
                else:
                    current_line.append({'text': display, 'bold': bold,
                                         'italic': italic, 'underline': underline})
                current_w += ww
                first_word_in_part = False

            if force_break_after:
                flush_line()

        if current_line:
            flush_lines_left = current_line
            visual_lines.append(flush_lines_left)

        # Rimuovi righe vuote di solo spazi che si trovano al centro (ma conserva quelle
        # deliberate per a-capo espliciti)
        return [line for line in visual_lines if line] or [[{'text': '', 'bold': False,
                                                              'italic': False, 'underline': False}]]

    def _count_rich_visual_lines(segs_list):
        return len(_split_rich_into_visual_lines(segs_list))

    for sec in extra_sections[:3]:
        titolo = sec['titolo'].upper()
        righe  = sec.get('righe', [])

        # Ogni elemento di righe è ora una lista di segmenti rich-text.
        # Per compatibilità con file vecchi (dove righe è lista di stringhe):
        def _to_segs(r):
            if isinstance(r, str):
                return [{'text': r, 'bold': False, 'italic': False, 'underline': False}]
            return r

        righe_segs = [_to_segs(r) for r in righe]

        # Calcola altezza box contando le righe visive reali
        total_lines = sum(_count_rich_visual_lines(r) for r in righe_segs)
        BOX_H = total_lines * ESEC_LH + len(righe_segs) * ESEC_GAP + 6*mm

        pb.gap(4*mm)
        # Ensure header (10mm) + box stay on the same page
        pb.ensure(10*mm + BOX_H + 4*mm)
        sec_bar(c, M, pb.y, titolo, "\U0001f4dd", ESEC_COLOR, CW)
        pb.y -= 10*mm
        rrect(c, M, pb.y - BOX_H, CW, BOX_H + 1*mm, r=3*mm,
              fill=ESEC_BG, stroke=ESEC_COLOR, sw=0.3)
        iy = pb.y - 4*mm
        for r_segs in righe_segs:
            visual_lines = _split_rich_into_visual_lines(r_segs)
            # Bullet point solo sulla prima riga visiva
            c.setFillColor(ESEC_COLOR)
            c.circle(M + 3*mm, iy + 0.5*mm, 0.9*mm, fill=1, stroke=0)
            for li, vline in enumerate(visual_lines):
                tx = ESEC_TEXT_X if li == 0 else ESEC_TEXT_X + 3*mm  # indent righe a capo
                _draw_rich_line(vline, tx, iy)
                iy -= ESEC_LH
            iy -= ESEC_GAP
        pb.y -= BOX_H + 4*mm

    cv_obj.save()
    print(f"✅ PDF generato: {output_path}  ({pb.page_num} pagine)")
    return output_path


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
def genera_pdf(excel_path, output_path=None):
    """Main function: read Excel → generate PDF."""
    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"File non trovato: {excel_path}")
    d = read_excel(excel_path)
    if output_path is None:
        nome_file = d['nome'].replace(' ', '_')
        folder = os.path.dirname(excel_path)
        output_path = os.path.join(folder, f"{nome_file}_PianoNutrizionale.pdf")
    build_pdf(d, output_path)
    return output_path


def _scegli_file_excel():
    """
    Apre una finestra di dialogo per selezionare un file Excel.
    Funziona su Windows, macOS e Linux (con tkinter installato).
    Restituisce il percorso scelto, oppure None se l'utente annulla.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()                    # nascondi la finestra principale
        root.attributes('-topmost', True)  # porta la dialog in primo piano

        percorso = filedialog.askopenfilename(
            title="Seleziona il file Excel del piano nutrizionale",
            filetypes=[
                ("File Excel", "*.xlsx *.xlsm *.xls"),
                ("Tutti i file", "*.*"),
            ],
        )
        root.destroy()
        return percorso if percorso else None

    except ImportError:
        print("⚠️  tkinter non disponibile. Usa la riga di comando:")
        print("   python3 MODELLO_genera_piano_nutrizionale_v22.py <file.xlsx> [output.pdf]")
        return None


if __name__ == '__main__':
    if len(sys.argv) < 2:
        # Nessun argomento → apri il file picker grafico
        print("📂 Nessun file specificato. Apertura selettore file...")
        excel = _scegli_file_excel()
        if not excel:
            print("❌ Nessun file selezionato. Operazione annullata.")
            sys.exit(0)
        out = None
    else:
        excel = sys.argv[1]
        out   = sys.argv[2] if len(sys.argv) > 2 else None

    try:
        pdf = genera_pdf(excel, out)
        print(f"📄 File salvato in: {pdf}")
    except FileNotFoundError as e:
        print(f"❌ Errore: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Errore durante la generazione del PDF: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)